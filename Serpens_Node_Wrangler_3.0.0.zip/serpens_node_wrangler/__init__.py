# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Serpens Node Wrangler",
    "author" : "Corza", 
    "description" : "A Node Wrangler made with Serpens for Serpens",
    "blender" : (3, 0, 0),
    "version" : (3, 0, 0),
    "location" : "Serpens Node Editor - NPanel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Node" 
}


import bpy
import bpy.utils.previews
import os
import blf
import gpu
from gpu_extras.batch import batch_for_shader
import bgl
from math import cos, sin, pi, hypot


addon_keymaps = {}
_icons = None
add_property_node = {'sna_cursorloc': [], 'sna_serpropnode': None, 'sna_serpdispnode': None, }
create_button_for_op = {'sna_store': '', }
create_operator_for_button = {'sna_storebutton': None, }
create_run_operator = {'sna_storepythonopname': '', 'sna_storeactivenode': None, }
find_node_by_uid = {'sna_new_variable': None, }
lazy_c_gpu_draw_wrangler = {'sna_start_x': 0.0, 'sna_start_y': 0.0, 'sna_view_to_region': False, 'sna_store_name_second_node': '', 'sna_store_bl_idname_second_node': '', 'sna_store_first_node': None, 'sna_store_second_node': None, 'sna_lazy_compare': False, 'sna_button_and_operator_link': False, 'sna_nothing_link': False, }
lazy_c_mouse_over_node_select = {'sna_new_variable': None, }
node_count = {'sna_uidstorenodecolor': [], 'sna_uidbool': False, 'sna_activenode_bl_idname': '', 'sna_node_count': 0, 'sna_to_from_nodes': [], 'sna_unused_count': [], 'sna_mouse_location': [], 'sna_toggle_bool_operator': False, 'sna_toggle_debug_node': False, }
quick_interface_function = {'sna_quick_store_interfacefunction': '', }
quick_print = {'sna_storeactnode': None, }


def sna_node_snippet__create_link_49C12_D2687(From_Node, From_Socket, To_Node, To_Socket):
    link_2C75A = bpy.context.area.spaces[0].node_tree.links.new(input=From_Node[From_Socket], output=To_Node[To_Socket], )


def sna_clear_all_print_nodes001_856F8_35287():
    for i_477AA in range(len(bpy.context.area.spaces[0].node_tree.nodes)):
        if (bpy.context.area.spaces[0].node_tree.nodes[i_477AA].bl_idname == 'SN_PrintNode'):
            bpy.ops.sn.clear_prints('INVOKE_DEFAULT', node_tree=bpy.context.area.spaces[0].node_tree.name, node=bpy.context.area.spaces[0].node_tree.nodes[i_477AA].name)
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()


def sna_create_node_at_mouse_location_C6B17_E81B8(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def region_by_type(area, region_type):
    for region in area.regions:
        if region.type == region_type:
            return region
    return area.regions[0]


def sna_update_sna_showdatapaths_AD6AF(self, context):
    sna_updated_prop = self.sna_showdatapaths
    if sna_updated_prop:
        handler_B13A0.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_draw_data_paths_3A859, (), 'WINDOW', 'POST_PIXEL'))
    else:
        if handler_B13A0:
            bpy.types.SpaceNodeEditor.draw_handler_remove(handler_B13A0[0], 'WINDOW')
            handler_B13A0.pop(0)


handler_B13A0 = []


def coords_view_to_region(area, coords):
    for region in area.regions:
        if region.type == "WINDOW":
            ui_scale = bpy.context.preferences.system.ui_scale
            return region.view2d.view_to_region(coords[0]*ui_scale, coords[1]*ui_scale, clip=False)
    return coords


def sna_create_node_at_mouse_location_2BDB4_A8719(Node, Offset_X, Offset_Y):
    node_DB070 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node, )
    node_DB070.location = (bpy.context.area.spaces[0].cursor_location[0] + Offset_X, bpy.context.area.spaces[0].cursor_location[1] + Offset_Y)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_DB070
    return node_DB070


def sna_node_snippet__create_node_FF49B_9480A(Type, Deselect_first, Set_active, Create_at_Cursor_Location, Move_after_create, Previous_node_location, Offset_X, Offset_Y):
    if Deselect_first:
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_FEC2E = bpy.context.area.spaces[0].node_tree.nodes.new(type=Type, )
    if Create_at_Cursor_Location:
        node_FEC2E.location = bpy.context.area.spaces[0].cursor_location
    else:
        node_FEC2E.location = (Previous_node_location[0] + Offset_X, Previous_node_location[1] + Offset_Y)
    if Move_after_create:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
    if Set_active:
        bpy.context.area.spaces[0].node_tree.nodes.active = node_FEC2E
    return [node_FEC2E, node_FEC2E.inputs, node_FEC2E.outputs, node_FEC2E.location]


def sna_node_snippet__create_node_FF49B_0F645(Type, Deselect_first, Set_active, Create_at_Cursor_Location, Move_after_create, Previous_node_location, Offset_X, Offset_Y):
    if Deselect_first:
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_FEC2E = bpy.context.area.spaces[0].node_tree.nodes.new(type=Type, )
    if Create_at_Cursor_Location:
        node_FEC2E.location = bpy.context.area.spaces[0].cursor_location
    else:
        node_FEC2E.location = (Previous_node_location[0] + Offset_X, Previous_node_location[1] + Offset_Y)
    if Move_after_create:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
    if Set_active:
        bpy.context.area.spaces[0].node_tree.nodes.active = node_FEC2E
    return [node_FEC2E, node_FEC2E.inputs, node_FEC2E.outputs, node_FEC2E.location]


handler_37344 = []


def sna_node_snippet__create_node_FF49B_FCFA3(Type, Deselect_first, Set_active, Create_at_Cursor_Location, Move_after_create, Previous_node_location, Offset_X, Offset_Y):
    if Deselect_first:
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_FEC2E = bpy.context.area.spaces[0].node_tree.nodes.new(type=Type, )
    if Create_at_Cursor_Location:
        node_FEC2E.location = bpy.context.area.spaces[0].cursor_location
    else:
        node_FEC2E.location = (Previous_node_location[0] + Offset_X, Previous_node_location[1] + Offset_Y)
    if Move_after_create:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
    if Set_active:
        bpy.context.area.spaces[0].node_tree.nodes.active = node_FEC2E
    return [node_FEC2E, node_FEC2E.inputs, node_FEC2E.outputs, node_FEC2E.location]


def sna_node_snippet__create_link_49C12_9A64F(From_Node, From_Socket, To_Node, To_Socket):
    link_2C75A = bpy.context.area.spaces[0].node_tree.links.new(input=From_Node[From_Socket], output=To_Node[To_Socket], )


def sna_node_snippet__create_link_49C12_9056C(From_Node, From_Socket, To_Node, To_Socket):
    link_2C75A = bpy.context.area.spaces[0].node_tree.links.new(input=From_Node[From_Socket], output=To_Node[To_Socket], )


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_create_node_mouse_loc_6399A_7A8E6(Create_Node, Give_it_a_Label):
    node_D5C68 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Create_Node, )
    node_D5C68.location = bpy.context.area.spaces[0].cursor_location
    node_D5C68.label = Give_it_a_Label
    return node_D5C68


def sna_create_node_offset_to_node_loc_253EE_1F621(Create_Node, Give_it_a_Label, Offset_X, Offset_Y):
    node_2528C = bpy.context.area.spaces[0].node_tree.nodes.new(type=Create_Node, )
    node_2528C.location = (bpy.context.area.spaces[0].cursor_location[0] + Offset_X, bpy.context.area.spaces[0].cursor_location[1] + Offset_Y)
    node_2528C.label = Give_it_a_Label
    return node_2528C.location


def sna_create_node_at_mouse_location_C6B17_B8502(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_A4C01(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_59149(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_E6251(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_AFC6D(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_6A345(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def sna_create_node_at_mouse_location_C6B17_32D85(Node_Bl_Idname, Move_after_creating, X_Offset, Y_Offset):
    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
    node_70907 = bpy.context.area.spaces[0].node_tree.nodes.new(type=Node_Bl_Idname, )
    node_70907.location = (bpy.context.area.spaces[0].cursor_location[0] + X_Offset, bpy.context.area.spaces[0].cursor_location[1] + Y_Offset)
    bpy.context.area.spaces[0].node_tree.nodes.active = node_70907
    if Move_after_creating:
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return node_70907
    else:
        return node_70907


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


_19F48_running = False
class SNA_OT_Modal_Operator_19F48(bpy.types.Operator):
    bl_idname = "sna.modal_operator_19f48"
    bl_label = "Modal Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_create_node_1: bpy.props.StringProperty(name='Create Node 1', description='', default='', subtype='NONE', maxlen=0)
    sna_create_node_2: bpy.props.StringProperty(name='Create Node 2', description='', default='', subtype='NONE', maxlen=0)
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not (len(bpy.context.scene.sn.properties.values()) == 0)
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _19F48_running
        _19F48_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _19F48_running
        if not context.area or not _19F48_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('DEFAULT')
        try:
            bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
            add_property_node['sna_serpropnode'].location = bpy.context.area.spaces[0].cursor_location
            add_property_node['sna_serpropnode'].prop_name = bpy.context.scene.sn.properties[bpy.context.scene.sn.property_index].name
            add_property_node['sna_serpdispnode'].location = (add_property_node['sna_serpropnode'].location[0] + 260.0, add_property_node['sna_serpropnode'].location[1] + 100.0)
            if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                self.execute(context)
                return {"FINISHED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _19F48_running
        if _19F48_running:
            _19F48_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            add_property_node['sna_cursorloc'] = list(bpy.context.area.spaces[0].cursor_location)
            node_52E86 = bpy.context.area.spaces[0].node_tree.nodes.new(type=self.sna_create_node_1, )
            add_property_node['sna_serpropnode'] = node_52E86
            node_52E86.location = (10000.0, 10000.0)
            node_CB5BA = bpy.context.area.spaces[0].node_tree.nodes.new(type=self.sna_create_node_2, )
            add_property_node['sna_serpdispnode'] = node_CB5BA
            node_CB5BA.location = (10000.0, 10000.0)
            sna_node_snippet__create_link_49C12_D2687(node_52E86.outputs, 0, node_CB5BA.inputs, 1)
            context.window_manager.modal_handler_add(self)
            _19F48_running = True
            return {'RUNNING_MODAL'}


def sna_add_to_sn_pt_propertypanel_7EB2D(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_propertiespanel_getset:
            col_00543 = layout.column(heading='', align=True)
            col_00543.alert = False
            col_00543.enabled = True
            col_00543.active = True
            col_00543.use_property_split = False
            col_00543.use_property_decorate = False
            col_00543.scale_x = 1.0
            col_00543.scale_y = 1.0
            col_00543.alignment = 'Expand'.upper()
            col_00543.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_00543.operator('sna.modal_operator_19f48', text='Get and Display Property', icon_value=600, emboss=True, depress=False)
            op.sna_create_node_1 = 'SN_SerpensPropertyNode'
            op.sna_create_node_2 = 'SN_DisplayPropertyNodeNew'
            op = col_00543.operator('sna.modal_operator_19f48', text='Get and Set Property', icon_value=599, emboss=True, depress=False)
            op.sna_create_node_1 = 'SN_SerpensPropertyNode'
            op.sna_create_node_2 = 'SN_SetPropertyNode'


class SNA_OT_Remove_Unused_Sockets_D0Ad5(bpy.types.Operator):
    bl_idname = "sna.remove_unused_sockets_d0ad5"
    bl_label = "Remove Unused Sockets"
    bl_description = "Remove unused sockets from an interface node"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        for i_A67EA in range(len(bpy.context.active_node.outputs)-1,-1,-1):
            if (not bpy.context.active_node.outputs[i_A67EA].dynamic):
                if (not bpy.context.active_node.outputs[i_A67EA].is_linked):
                    bpy.ops.sn.remove_socket('INVOKE_DEFAULT', node=bpy.context.active_node.name, is_output=True, index=i_A67EA)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clean_sockets_ADA06(layout_function, ):
    if bpy.context.active_node:
        if (len(bpy.context.active_node.outputs.values()) > 0):
            for i_8E58A in range(len(bpy.context.active_node.outputs)):
                pass
            row_7D20C = layout_function.row(heading='', align=False)
            row_7D20C.alert = False
            row_7D20C.enabled = ((not bpy.context.active_node.outputs[i_8E58A].is_linked) and bpy.context.active_node.outputs[i_8E58A].dynamic and (not bpy.context.active_node.outputs[i_8E58A].is_variable) and (len(bpy.context.selected_nodes) == 1) and ( not 'Frame' in bpy.context.active_node.bl_idname or  not 'Key' in bpy.context.active_node.bl_idname))
            row_7D20C.active = ((not bpy.context.active_node.outputs[i_8E58A].is_linked) and bpy.context.active_node.outputs[i_8E58A].dynamic and (not bpy.context.active_node.outputs[i_8E58A].is_variable) and (len(bpy.context.selected_nodes) == 1) and ( not 'Frame' in bpy.context.active_node.bl_idname or  not 'Key' in bpy.context.active_node.bl_idname))
            row_7D20C.use_property_split = False
            row_7D20C.use_property_decorate = False
            row_7D20C.scale_x = 1.0
            row_7D20C.scale_y = 1.0
            row_7D20C.alignment = 'Expand'.upper()
            row_7D20C.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
            col_CB573 = row_7D20C.column(heading='', align=False)
            col_CB573.alert = False
            col_CB573.enabled = True
            col_CB573.active = True
            col_CB573.use_property_split = False
            col_CB573.use_property_decorate = False
            col_CB573.scale_x = 1.0
            col_CB573.scale_y = 1.0
            col_CB573.alignment = 'Expand'.upper()
            op = col_CB573.operator('sna.remove_unused_sockets_d0ad5', text='Remove Unused Sockets', icon_value=25, emboss=True, depress=False)
    else:
        row_022CC = layout_function.row(heading='', align=False)
        row_022CC.alert = False
        row_022CC.enabled = False
        row_022CC.active = False
        row_022CC.use_property_split = False
        row_022CC.use_property_decorate = False
        row_022CC.scale_x = 1.0
        row_022CC.scale_y = 1.0
        row_022CC.alignment = 'Expand'.upper()
        row_022CC.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_022CC.operator('sna.remove_unused_sockets_d0ad5', text='Remove Unused Sockets', icon_value=25, emboss=True, depress=False)


class SNA_OT_Clear_All_Print_Nodes_133D5(bpy.types.Operator):
    bl_idname = "sna.clear_all_print_nodes_133d5"
    bl_label = "Clear all Print Nodes"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_clear_all_print_nodes001_856F8_35287()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clear_all_print_nodes001_52173(layout_function, ):
    op = layout_function.operator('sna.clear_all_print_nodes_133d5', text='Clear All Print Nodes', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)


def sna_create_button_4_op_3081B(layout_function, ):
    if property_exists("bpy.context.active_node.bl_idname", globals(), locals()):
        row_A4525 = layout_function.row(heading='', align=False)
        row_A4525.alert = False
        row_A4525.enabled = (bpy.context.active_node.bl_idname == 'SN_OperatorNode')
        row_A4525.active = (bpy.context.active_node.bl_idname == 'SN_OperatorNode')
        row_A4525.use_property_split = False
        row_A4525.use_property_decorate = False
        row_A4525.scale_x = 1.0
        row_A4525.scale_y = 1.0
        row_A4525.alignment = 'Expand'.upper()
        row_A4525.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_A4525.operator('sna.create_button_4_op_9c3eb', text='Create a Button for Operator', icon_value=216, emboss=True, depress=False)
    else:
        row_56160 = layout_function.row(heading='', align=False)
        row_56160.alert = False
        row_56160.enabled = False
        row_56160.active = False
        row_56160.use_property_split = False
        row_56160.use_property_decorate = False
        row_56160.scale_x = 1.0
        row_56160.scale_y = 1.0
        row_56160.alignment = 'Expand'.upper()
        row_56160.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_56160.operator('sna.create_button_4_op_9c3eb', text='Create a Button for Operator', icon_value=216, emboss=True, depress=False)


class SNA_OT_Create_Button_4_Op_9C3Eb(bpy.types.Operator):
    bl_idname = "sna.create_button_4_op_9c3eb"
    bl_label = "create_button_4_op"
    bl_description = "Select an Operator Node to create a Button for"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if (bpy.context.active_node.bl_idname == 'SN_OperatorNode'):
            create_button_for_op['sna_store'] = bpy.context.active_node.name
            node_0_e81b8 = sna_create_node_at_mouse_location_C6B17_E81B8('SN_ButtonNodeNew', True, 0.0, 0.0)
            bpy.context.active_node.source_type = 'CUSTOM'
            bpy.context.active_node['ref_ntree'] = bpy.context.area.spaces[0].node_tree
            bpy.context.active_node.ref_SN_OperatorNode = create_button_for_op['sna_store']
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Create_Operator_For_Button_Op_D1E5A(bpy.types.Operator):
    bl_idname = "sna.create_operator_for_button_op_d1e5a"
    bl_label = "Create Operator for Button Op"
    bl_description = "Select a Button Node to create an Operator for"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        create_operator_for_button['sna_storebutton'] = None
        create_operator_for_button['sna_storebutton'] = bpy.context.active_node
        bpy.context.active_node.source_type = 'CUSTOM'
        bpy.context.active_node['ref_ntree'] = bpy.context.area.spaces[0].node_tree
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        node_B9542 = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_OperatorNode', )
        create_operator_for_button['sna_storebutton'].ref_SN_OperatorNode = node_B9542.name
        node_B9542.location = bpy.context.area.spaces[0].cursor_location
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_create_operator_for_button_2723E(layout_function, ):
    if bpy.context.active_node:
        row_19B78 = layout_function.row(heading='', align=False)
        row_19B78.alert = False
        row_19B78.enabled = (((bpy.context.active_node.bl_idname == 'SN_ButtonNode') or (bpy.context.active_node.bl_idname == 'SN_ButtonNodeNew')) and (len(bpy.context.selected_nodes) == 1))
        row_19B78.active = (((bpy.context.active_node.bl_idname == 'SN_ButtonNode') or (bpy.context.active_node.bl_idname == 'SN_ButtonNodeNew')) and (len(bpy.context.selected_nodes) == 1))
        row_19B78.use_property_split = False
        row_19B78.use_property_decorate = False
        row_19B78.scale_x = 1.0
        row_19B78.scale_y = 1.0
        row_19B78.alignment = 'Expand'.upper()
        row_19B78.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_19B78.operator('sna.create_operator_for_button_op_d1e5a', text='Create an Operator for Button', icon_value=216, emboss=True, depress=False)
    else:
        row_076FF = layout_function.row(heading='', align=False)
        row_076FF.alert = False
        row_076FF.enabled = False
        row_076FF.active = False
        row_076FF.use_property_split = False
        row_076FF.use_property_decorate = False
        row_076FF.scale_x = 1.0
        row_076FF.scale_y = 1.0
        row_076FF.alignment = 'Expand'.upper()
        row_076FF.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_076FF.operator('sna.create_operator_for_button_op_d1e5a', text='Create an Operator for Button', icon_value=216, emboss=True, depress=False)


class SNA_OT_Cloneop_343Ed(bpy.types.Operator):
    bl_idname = "sna.cloneop_343ed"
    bl_label = "cloneop"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Buttonop_F04Db(bpy.types.Operator):
    bl_idname = "sna.buttonop_f04db"
    bl_label = "ButtonOp"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        create_run_operator['sna_storeactivenode'] = None
        create_run_operator['sna_storeactivenode'] = bpy.context.active_node
        node_6AA48 = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_ButtonNodeNew', )
        node_6AA48.location = bpy.context.area.spaces[0].cursor_location
        node_6AA48.source_type = 'CUSTOM'
        node_6AA48.ref_SN_OperatorNode = create_run_operator['sna_storeactivenode'].name
        print(create_run_operator['sna_storeactivenode'].name)
        bpy.ops.node.detach_translate_attach('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Runop_46D45(bpy.types.Operator):
    bl_idname = "sna.runop_46d45"
    bl_label = "RunOp"
    bl_description = "Select an Operator Node to create a Run Operator for"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        create_run_operator['sna_storeactivenode'] = None
        create_run_operator['sna_storeactivenode'] = bpy.context.active_node
        node_A013E = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_RunOperatorNode', )
        node_A013E.location = bpy.context.area.spaces[0].cursor_location
        node_A013E.ref_SN_OperatorNode = create_run_operator['sna_storeactivenode'].name
        node_A013E.source_type = 'CUSTOM'
        node_A013E = bpy.context.area.spaces[0].node_tree
        bpy.ops.node.detach_translate_attach('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_create_run_operator_FC5F3(layout_function, ):
    if bpy.context.active_node:
        row_EA1D7 = layout_function.row(heading='', align=False)
        row_EA1D7.alert = False
        row_EA1D7.enabled = (bpy.context.active_node.bl_idname == 'SN_OperatorNode')
        row_EA1D7.active = (bpy.context.active_node.bl_idname == 'SN_OperatorNode')
        row_EA1D7.use_property_split = False
        row_EA1D7.use_property_decorate = False
        row_EA1D7.scale_x = 1.0
        row_EA1D7.scale_y = 1.0
        row_EA1D7.alignment = 'Expand'.upper()
        row_EA1D7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_EA1D7.operator('sna.runop_46d45', text='Create a Run Operator for Operator', icon_value=216, emboss=True, depress=False)
    else:
        row_723EB = layout_function.row(heading='', align=False)
        row_723EB.alert = False
        row_723EB.enabled = False
        row_723EB.active = False
        row_723EB.use_property_split = False
        row_723EB.use_property_decorate = False
        row_723EB.scale_x = 1.0
        row_723EB.scale_y = 1.0
        row_723EB.alignment = 'Expand'.upper()
        row_723EB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_723EB.operator('sna.runop_46d45', text='Create a Run Operator for Operator', icon_value=216, emboss=True, depress=False)


def sna_draw_data_paths_3A859():
    if (bpy.context.area.ui_type == 'ScriptingNodesTree'):
        if (len(bpy.context.selected_nodes) == 0):
            font_id = 0
            if r'' and os.path.exists(r''):
                font_id = blf.load(r'')
            if font_id == -1:
                print("Couldn't load font!")
            else:
                blf.position(font_id, tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[0], tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[1], 0)
                blf.size(font_id, bpy.context.scene.sna_datapathstextsize, 72)
                clr = (1.0, 1.0, 1.0, 0.4192359447479248)
                blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                if 1000:
                    blf.enable(font_id, blf.WORD_WRAP)
                    blf.word_wrap(font_id, 1000)
                if 0.0:
                    blf.enable(font_id, blf.ROTATION)
                    blf.rotation(font_id, 0.0)
                blf.enable(font_id, blf.WORD_WRAP)
                blf.draw(font_id, '[ No Active Node ]')
                blf.disable(font_id, blf.ROTATION)
                blf.disable(font_id, blf.WORD_WRAP)
        else:
            if (len(bpy.context.selected_nodes) == 1):
                if property_exists("bpy.context.active_node.pasted_data_path", globals(), locals()):
                    font_id = 0
                    if r'' and os.path.exists(r''):
                        font_id = blf.load(r'')
                    if font_id == -1:
                        print("Couldn't load font!")
                    else:
                        blf.position(font_id, tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[0], tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[1], 0)
                        blf.size(font_id, bpy.context.scene.sna_datapathstextsize, 72)
                        clr = (1.0, 1.0, 1.0, 0.4192360043525696)
                        blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                        if 1000:
                            blf.enable(font_id, blf.WORD_WRAP)
                            blf.word_wrap(font_id, 1000)
                        if 0.0:
                            blf.enable(font_id, blf.ROTATION)
                            blf.rotation(font_id, 0.0)
                        blf.enable(font_id, blf.WORD_WRAP)
                        blf.draw(font_id, bpy.context.active_node.pasted_data_path[4:].replace("['", ' > ').replace("']", '').replace('.0', '///').replace('.', ' > ').replace('///', '.0').replace('_', ' ').replace('areas[0] > ', 'space data > ').replace('spaces[0] > ', '').replace('screen >', ''))
                        blf.disable(font_id, blf.ROTATION)
                        blf.disable(font_id, blf.WORD_WRAP)
                else:
                    font_id = 0
                    if r'' and os.path.exists(r''):
                        font_id = blf.load(r'')
                    if font_id == -1:
                        print("Couldn't load font!")
                    else:
                        blf.position(font_id, tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[0], tuple(map(lambda v: int(v), ((0, region_by_type(bpy.context.area, 'WINDOW').height)[0] + 50.0, (0, region_by_type(bpy.context.area, 'WINDOW').height)[1] - 30.0)))[1], 0)
                        blf.size(font_id, bpy.context.scene.sna_datapathstextsize, 72)
                        clr = (1.0, 1.0, 1.0, 0.4192359447479248)
                        blf.color(font_id, clr[0], clr[1], clr[2], clr[3])
                        if 1000:
                            blf.enable(font_id, blf.WORD_WRAP)
                            blf.word_wrap(font_id, 1000)
                        if 0.0:
                            blf.enable(font_id, blf.ROTATION)
                            blf.rotation(font_id, 0.0)
                        blf.enable(font_id, blf.WORD_WRAP)
                        blf.draw(font_id, '[ No Datapath for this node in Blend Data Browser]')
                        blf.disable(font_id, blf.ROTATION)
                        blf.disable(font_id, blf.WORD_WRAP)


def sna_asdfasdf_4CF63(Color, Width, P1, P2):
    if (bpy.app.version > (3, 3, 9999)):
        coords = ((P1[0], P1[1]), (P2[0], P2[1]))
        colour = [(Color),
                  (Color),
                 ]
        shader = gpu.shader.from_builtin('2D_POLYLINE_SMOOTH_COLOR')
        shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
        shader.uniform_float("lineWidth", Width)
        batch = batch_for_shader(shader, 'LINES', {"pos": coords, "color": colour})
        gpu.state.depth_test_set('NONE')
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set('ALPHA')
        batch.draw(shader)
    else:
        coords = ((P1[0], P1[1]), (P2[0], P2[1]))
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", Color)
        bgl.glLineWidth(Width)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glEnable(bgl.GL_LINE_SMOOTH)
        batch.draw(shader)


def sna_draw_rounded_box_first_2648C(Width, Color, Second_Node):
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 10.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 2.0))), coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 2.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 2.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 2.0))), coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 0.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 1.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 0.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 1.0))), coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + -1.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + -2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + -1.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + -1.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + -16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + 10.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + 2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + -10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + -1.0, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] + -16.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + -10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + -2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + -2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 1.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + 1.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + -2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + -16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1])[1] + -16.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -1.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -1.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 0.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 0.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -2.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -1.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 0.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -1.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 0.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 0.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 1.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + 16.0))))
    sna_asdfasdf_4CF63(Color, Width, coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + 10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0], ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))), coords_view_to_region(bpy.context.area, tuple(((((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[0] + -10.0, (((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[0] + (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[0] / bpy.context.preferences.system.ui_scale, ((lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[0] + 1.0, (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).location[1] - 1.0)[1] - (lazy_c_gpu_draw_wrangler['sna_store_second_node'] if Second_Node else lazy_c_gpu_draw_wrangler['sna_store_first_node']).dimensions[1] * 0.9800000190734863 / bpy.context.preferences.system.ui_scale)[1] + -2.0))))


class SNA_OT_Find_Uid_0706D(bpy.types.Operator):
    bl_idname = "sna.find_uid_0706d"
    bl_label = "Find_UID"
    bl_description = "Find a node on any graph by it's UID"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        for i_D8CC7 in range(len(bpy.data.node_groups)):
            for i_D1F6A in range(len(bpy.data.node_groups[i_D8CC7].nodes)):
                if (property_exists("bpy.data.node_groups[i_D8CC7].nodes[i_D1F6A].static_uid", globals(), locals()) and (bpy.data.node_groups[i_D8CC7].nodes[i_D1F6A].static_uid == bpy.context.scene.sna_find_uid)):
                    bpy.context.area.spaces[0].node_tree = bpy.data.node_groups[i_D8CC7]
                    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
                    bpy.data.node_groups[i_D8CC7].nodes[i_D1F6A].select = True
                    bpy.context.area.spaces[0].node_tree.nodes.active = bpy.data.node_groups[i_D8CC7].nodes[i_D1F6A]
                    bpy.ops.node.view_selected('INVOKE_DEFAULT', )
                    bpy.context.scene.sn.node_tree_index = i_D8CC7
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_find_uid_F54AB(layout_function, ):
    row_515BC = layout_function.row(heading='', align=True)
    row_515BC.alert = False
    row_515BC.enabled = True
    row_515BC.active = True
    row_515BC.use_property_split = False
    row_515BC.use_property_decorate = False
    row_515BC.scale_x = 1.0
    row_515BC.scale_y = 1.0
    row_515BC.alignment = 'Expand'.upper()
    row_515BC.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
    row_515BC.label(text='Find node by UID', icon_value=0)
    row_515BC.prop(bpy.context.scene, 'sna_find_uid', text='', icon_value=0, emboss=True)
    op = row_515BC.operator('sna.find_uid_0706d', text='', icon_value=30, emboss=True, depress=False)


def sna_find_nodes_B70F8(layout_function, ):
    op = layout_function.operator('wm.call_panel', text='Find Node on Graph', icon_value=30, emboss=True, depress=False)
    op.name = 'NODE_PT_searchnodes'
    op.keep_open = True


class SNA_OT_Operator_62639(bpy.types.Operator):
    bl_idname = "sna.operator_62639"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_node: bpy.props.StringProperty(name='node', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        bpy.context.area.spaces[0].node_tree.nodes[self.sna_node].select = True
        bpy.ops.node.view_selected('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class NODE_PT_searchnodes(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'NODE_PT_searchnodes'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Find Node on Current Graph', icon_value=16)
        layout.prop(bpy.context.scene, 'sna_findnodes_stringinput', text='Search', icon_value=0, emboss=True)
        for i_2F6D5 in range(len(bpy.context.area.spaces[0].node_tree.nodes)):
            if bpy.context.scene.sna_findnodes_stringinput in bpy.context.area.spaces[0].node_tree.nodes[i_2F6D5].name or bpy.context.scene.sna_findnodes_stringinput in bpy.context.area.spaces[0].node_tree.nodes[i_2F6D5].name.lower():
                op = layout.operator('sna.operator_62639', text=bpy.context.area.spaces[0].node_tree.nodes[i_2F6D5].name, icon_value=0, emboss=True, depress=False)
                op.sna_node = bpy.context.area.spaces[0].node_tree.nodes[i_2F6D5].name


def sna_get_full_operator_4BA5D(layout_function, ):
    if property_exists("bpy.context.active_node.bl_idname", globals(), locals()):
        row_37CFC = layout_function.row(heading='', align=False)
        row_37CFC.alert = False
        row_37CFC.enabled = ((bpy.context.active_node.bl_idname == 'SN_OperatorNode') or (bpy.context.active_node.bl_idname == 'SN_ModalOperatorNode'))
        row_37CFC.active = ((bpy.context.active_node.bl_idname == 'SN_OperatorNode') or (bpy.context.active_node.bl_idname == 'SN_ModalOperatorNode'))
        row_37CFC.use_property_split = False
        row_37CFC.use_property_decorate = False
        row_37CFC.scale_x = 1.0
        row_37CFC.scale_y = 1.0
        row_37CFC.alignment = 'Expand'.upper()
        row_37CFC.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_37CFC.operator('sna.get_full_operator_182b8', text='Get Operator Full Python Path', icon_value=676, emboss=True, depress=False)
    else:
        row_775B9 = layout_function.row(heading='', align=False)
        row_775B9.alert = False
        row_775B9.enabled = False
        row_775B9.active = False
        row_775B9.use_property_split = False
        row_775B9.use_property_decorate = False
        row_775B9.scale_x = 1.0
        row_775B9.scale_y = 1.0
        row_775B9.alignment = 'Expand'.upper()
        row_775B9.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_775B9.operator('sna.get_full_operator_182b8', text='Get Operator Full ID', icon_value=676, emboss=True, depress=False)


class SNA_OT_Get_Full_Operator_182B8(bpy.types.Operator):
    bl_idname = "sna.get_full_operator_182b8"
    bl_label = "get_full_operator"
    bl_description = "Select an Operator to copy its full path: bpy.ops.sna.operator45t2e() for example"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.window_manager.clipboard = 'bpy.ops.sna.' + bpy.context.active_node.operator_python_name + '()'
        self.report({'INFO'}, message='Copied to Clipboard:    ' + 'bpy.ops.sna.' + bpy.context.active_node.operator_python_name + '()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_B6298_running = False
class SNA_OT_Modal_Operator_B6298(bpy.types.Operator):
    bl_idname = "sna.modal_operator_b6298"
    bl_label = "Modal Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _B6298_running
        _B6298_running = False
        context.window.cursor_set("DEFAULT")
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _B6298_running
        if not context.area or not _B6298_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            pass
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _B6298_running
        if _B6298_running:
            _B6298_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            context.window_manager.modal_handler_add(self)
            _B6298_running = True
            return {'RUNNING_MODAL'}


class SNA_OT_Graph_Label_Op_Cba49(bpy.types.Operator):
    bl_idname = "sna.graph_label_op_cba49"
    bl_label = "Graph Label Op"
    bl_description = "Adds a frame with the label prefilled in for a quick labelling system"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        node_0_a8719 = sna_create_node_at_mouse_location_2BDB4_A8719('NodeFrame', 0.0, 0.0)
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        bpy.context.active_node.width = 1248.0
        bpy.context.active_node.height = 90.0
        bpy.context.active_node.label = 'Graph Label'
        bpy.context.active_node.use_custom_color = True
        bpy.context.active_node.label_size = 64
        bpy.context.active_node.color = (0.06997500360012054, 0.06997500360012054, 0.06997500360012054)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_keypress_operator_C5375(layout_function, ):
    row_0DDC4 = layout_function.row(heading='', align=True)
    row_0DDC4.alert = False
    row_0DDC4.enabled = True
    row_0DDC4.active = True
    row_0DDC4.use_property_split = False
    row_0DDC4.use_property_decorate = False
    row_0DDC4.scale_x = 1.0
    row_0DDC4.scale_y = 1.0
    row_0DDC4.alignment = 'Expand'.upper()
    row_0DDC4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = row_0DDC4.operator('sna.keypress_operator001_18cc9', text='Keypress Operator', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)
    op = row_0DDC4.operator('wm.call_panel', text='', icon_value=213, emboss=True, depress=False)
    op.name = 'CRZ_PT_keypressoperator'


class CRZ_PT_keypressoperator(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'CRZ_PT_keypressoperator'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_7EDA0 = layout.column(heading='', align=False)
        col_7EDA0.alert = False
        col_7EDA0.enabled = True
        col_7EDA0.active = True
        col_7EDA0.use_property_split = False
        col_7EDA0.use_property_decorate = False
        col_7EDA0.scale_x = 1.0
        col_7EDA0.scale_y = 1.0
        col_7EDA0.alignment = 'Expand'.upper()
        col_7EDA0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_7EDA0.label(text='Default Keypress Settings', icon_value=0)
        col_7EDA0.prop(bpy.context.scene, 'sna_keypress_key', text='Key', icon_value=0, emboss=True)
        col_7EDA0.prop(bpy.context.scene, 'sna_keypress_shift', text='Shift', icon_value=0, emboss=True)
        col_7EDA0.prop(bpy.context.scene, 'sna_keypress_ctrl', text='Ctrl', icon_value=0, emboss=True)
        col_7EDA0.prop(bpy.context.scene, 'sna_keypress_alt', text='Alt', icon_value=0, emboss=True)
        box_E8B22 = col_7EDA0.box()
        box_E8B22.alert = False
        box_E8B22.enabled = True
        box_E8B22.active = True
        box_E8B22.use_property_split = False
        box_E8B22.use_property_decorate = False
        box_E8B22.alignment = 'Expand'.upper()
        box_E8B22.scale_x = 1.0
        box_E8B22.scale_y = 1.0
        box_E8B22.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_12D30 = box_E8B22.column(heading='', align=True)
        col_12D30.alert = False
        col_12D30.enabled = True
        col_12D30.active = True
        col_12D30.use_property_split = False
        col_12D30.use_property_decorate = False
        col_12D30.scale_x = 1.0
        col_12D30.scale_y = 1.0
        col_12D30.alignment = 'Expand'.upper()
        col_12D30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_12D30.label(text='*Use the Modal Shortcut Node to find ', icon_value=0)
        col_12D30.label(text='proper keymap name', icon_value=0)


class SNA_OT_Keypress_Operator001_18Cc9(bpy.types.Operator):
    bl_idname = "sna.keypress_operator001_18cc9"
    bl_label = "Keypress Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        node_0_9480a, input_sockets_1_9480a, output_sockets_2_9480a, location_3_9480a = sna_node_snippet__create_node_FF49B_9480A('SN_OnKeypressNode', True, True, True, False, (1.0, 1.0, 1.0), 0.0, 0.0)
        node_0_0f645, input_sockets_1_0f645, output_sockets_2_0f645, location_3_0f645 = sna_node_snippet__create_node_FF49B_0F645('SN_OperatorNode', False, False, False, True, location_3_9480a, 250.0, 0.0)
        node_0_9480a.parent_type = 'CUSTOM'
        node_0_9480a.ref_SN_OperatorNode = node_0_0f645.name
        node_0_9480a.key = bpy.context.scene.sna_keypress_key
        node_0_9480a.ctrl = bpy.context.scene.sna_keypress_ctrl
        node_0_9480a.alt = bpy.context.scene.sna_keypress_alt
        node_0_9480a.shift = bpy.context.scene.sna_keypress_shift
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_check_socket_type_and_store_in_D240E():
    for i_92593 in range(len(lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs)):
        if (not lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_92593].hide):
            return [lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_92593].bl_idname, lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname]


def sna_check_socket_type_and_store_out_77CE8():
    for i_08182 in range(len(lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs)):
        if (not lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[i_08182].hide):
            return [lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[i_08182].bl_idname, lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname]


_2B170_running = False
class SNA_OT_Lazy_Modal_2B170(bpy.types.Operator):
    bl_idname = "sna.lazy_modal_2b170"
    bl_label = "Lazy Modal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not (not (bpy.context.area.ui_type == 'ScriptingNodesTree'))
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _2B170_running
        _2B170_running = False
        context.window.cursor_set("DEFAULT")
        if handler_37344:
            bpy.types.SpaceNodeEditor.draw_handler_remove(handler_37344[0], 'WINDOW')
            handler_37344.pop(0)
        if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] != None):
            lazy_c_gpu_draw_wrangler['sna_store_name_second_node'] = lazy_c_gpu_draw_wrangler['sna_store_second_node'].name
            lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] = lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname
            if lazy_c_gpu_draw_wrangler['sna_lazy_compare']:
                bpy.ops.sna.lazy_compare_bf0ca('INVOKE_DEFAULT', )
                bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
            else:
                if lazy_c_gpu_draw_wrangler['sna_button_and_operator_link']:
                    bpy.ops.sna.lazy_link_c08e5('INVOKE_DEFAULT', )
                    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
                else:
                    bpy.ops.sna.lazy_join_2947e('INVOKE_DEFAULT', )
                    bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _2B170_running
        if not context.area or not _2B170_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('DEFAULT')
        try:
            sna_mouse_over_node_select_4EE67(False)
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
            output_0_f64ac = sna_if_first_node_is_4B3B5()
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _2B170_running
        if _2B170_running:
            _2B170_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            lazy_c_gpu_draw_wrangler['sna_store_first_node'] = None
            lazy_c_gpu_draw_wrangler['sna_store_second_node'] = None
            sna_mouse_over_node_select_4EE67(True)
            lazy_c_gpu_draw_wrangler['sna_start_x'] = bpy.context.area.spaces[0].cursor_location[0]
            lazy_c_gpu_draw_wrangler['sna_start_y'] = bpy.context.area.spaces[0].cursor_location[1]
            handler_37344.append(bpy.types.SpaceNodeEditor.draw_handler_add(sna_lazy_connect_draw_A2BD0, (), 'WINDOW', 'POST_PIXEL'))
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
            context.window_manager.modal_handler_add(self)
            _2B170_running = True
            return {'RUNNING_MODAL'}


def sna_lazy_connect_draw_A2BD0():
    if (bpy.context.area.ui_type == 'ScriptingNodesTree'):
        if lazy_c_gpu_draw_wrangler['sna_button_and_operator_link']:
            if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] != None):
                if lazy_c_gpu_draw_wrangler['sna_lazy_compare']:
                    sna_func_6EF92(bpy.context.scene.sna_lazy_compare_color, (bpy.context.scene.sna_lazy_compare_color[0] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[1] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[2] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[3] + -0.25))
                else:
                    sna_func_6EF92(bpy.context.scene.sna_lazy_link_color, (bpy.context.scene.sna_lazy_link_color[0], bpy.context.scene.sna_lazy_link_color[1], bpy.context.scene.sna_lazy_link_color[2] + 0.0, bpy.context.scene.sna_lazy_link_color[3] + -0.25))
            else:
                sna_func_6EF92(bpy.context.scene.sna_lazy_blank_color, (bpy.context.scene.sna_lazy_blank_color[0], bpy.context.scene.sna_lazy_blank_color[1], bpy.context.scene.sna_lazy_blank_color[2] + 0.0, bpy.context.scene.sna_lazy_blank_color[3] + -0.30000001192092896))
        else:
            if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] != None):
                if lazy_c_gpu_draw_wrangler['sna_lazy_compare']:
                    sna_func_6EF92(bpy.context.scene.sna_lazy_compare_color, (bpy.context.scene.sna_lazy_compare_color[0] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[1] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[2] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[3] + -0.25))
                else:
                    sna_func_6EF92(bpy.context.scene.sna_lazy_connect_color, (bpy.context.scene.sna_lazy_connect_color[0], bpy.context.scene.sna_lazy_connect_color[1], bpy.context.scene.sna_lazy_connect_color[2] + -0.25, bpy.context.scene.sna_lazy_connect_color[3] + -0.4000000059604645))
            else:
                sna_func_6EF92(bpy.context.scene.sna_lazy_blank_color, (bpy.context.scene.sna_lazy_blank_color[0], bpy.context.scene.sna_lazy_blank_color[1], bpy.context.scene.sna_lazy_blank_color[2] + 0.0, bpy.context.scene.sna_lazy_blank_color[3] + -0.30000001192092896))
        if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] != None):
            if lazy_c_gpu_draw_wrangler['sna_button_and_operator_link']:
                if lazy_c_gpu_draw_wrangler['sna_lazy_compare']:
                    sna_func_DEF24(bpy.context.scene.sna_lazy_compare_color, (bpy.context.scene.sna_lazy_compare_color[0] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[1] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[2] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[3] + -0.25))
                else:
                    sna_func_DEF24(bpy.context.scene.sna_lazy_link_color, (bpy.context.scene.sna_lazy_link_color[0], bpy.context.scene.sna_lazy_link_color[1], bpy.context.scene.sna_lazy_link_color[2] + 0.0, bpy.context.scene.sna_lazy_link_color[3] + -0.25))
            else:
                if lazy_c_gpu_draw_wrangler['sna_lazy_compare']:
                    sna_func_DEF24(bpy.context.scene.sna_lazy_compare_color, (bpy.context.scene.sna_lazy_compare_color[0] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[1] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[2] + -0.20000000298023224, bpy.context.scene.sna_lazy_compare_color[3] + -0.25))
                else:
                    sna_func_DEF24(bpy.context.scene.sna_lazy_connect_color, (bpy.context.scene.sna_lazy_connect_color[0], bpy.context.scene.sna_lazy_connect_color[1], bpy.context.scene.sna_lazy_connect_color[2] + -0.25, bpy.context.scene.sna_lazy_connect_color[3] + -0.4000000059604645))


class SNA_OT_Lazy_Node_Detect_04D4C(bpy.types.Operator):
    bl_idname = "sna.lazy_node_detect_04d4c"
    bl_label = "Lazy Node Detect"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not (not (bpy.context.area.ui_type == 'ScriptingNodesTree'))

    def execute(self, context):
        if sna_mouse_over_node_select_4EE67(True):
            lazy_c_gpu_draw_wrangler['sna_lazy_compare'] = False
            bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
            bpy.ops.sna.lazy_modal_2b170('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Lazy_Nodes_Detect_1C7Ca(bpy.types.Operator):
    bl_idname = "sna.lazy_nodes_detect_1c7ca"
    bl_label = "Lazy Nodes Detect"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not (not (bpy.context.area.ui_type == 'ScriptingNodesTree'))

    def execute(self, context):
        if sna_mouse_over_node_select_4EE67(True):
            lazy_c_gpu_draw_wrangler['sna_lazy_compare'] = True
            bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
            bpy.ops.sna.lazy_modal_2b170('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Lazy_Compare_Bf0Ca(bpy.types.Operator):
    bl_idname = "sna.lazy_compare_bf0ca"
    bl_label = "Lazy Compare"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not (not (bpy.context.area.ui_type == 'ScriptingNodesTree'))

    def execute(self, context):
        node_0_fcfa3, input_sockets_1_fcfa3, output_sockets_2_fcfa3, location_3_fcfa3 = sna_node_snippet__create_node_FF49B_FCFA3('SN_CompareNode', True, True, False, False, lazy_c_gpu_draw_wrangler['sna_store_first_node'].location, lazy_c_gpu_draw_wrangler['sna_store_first_node'].width + 60.0, 0.0)
        sna_node_snippet__create_link_49C12_9A64F(lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs, (1 if (lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_BlenderPropertyNode') else 0), input_sockets_1_fcfa3, 0)
        sna_node_snippet__create_link_49C12_9056C(lazy_c_gpu_draw_wrangler['sna_store_second_node'].outputs, (1 if (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_BlenderPropertyNode') else 0), input_sockets_1_fcfa3, 1)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_func_6EF92(Color_1, Color_2):
    sna_draw_rounded_box_first_2648C(2.0, Color_1, False)
    vertices = [(4.0 * cos(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[0],
                4.0 * sin(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[1])
                for i in range(12 + 1)]
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": vertices})
    shader.bind()
    shader.uniform_float("color", Color_1)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)

    def points():
        new_var = [(4.0 * cos(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[0],
        4.0 * sin(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[1]) 
        for i in range(12 + 1)]
        return new_var
    vertices = [(4.0 * cos(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0],
                4.0 * sin(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1])
                for i in range(12 + 1)]
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": vertices})
    shader.bind()
    shader.uniform_float("color", Color_1)
    gpu.state.blend_set('ALPHA')
    batch.draw(shader)

    def points():
        new_var = [(4.0 * cos(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0],
        4.0 * sin(i * 2 * pi / 12) + coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]) 
        for i in range(12 + 1)]
        return new_var
    if (bpy.app.version > (3, 3, 9999)):
        coords = ((coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[0], coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[1]), (coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0], coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]))
        colour = [(Color_1),
                  (Color_1),
                 ]
        shader = gpu.shader.from_builtin('2D_POLYLINE_SMOOTH_COLOR')
        shader.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
        shader.uniform_float("lineWidth", 2.0)
        batch = batch_for_shader(shader, 'LINES', {"pos": coords, "color": colour})
        gpu.state.depth_test_set('ALWAYS')
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set('ALPHA')
        batch.draw(shader)
    else:
        coords = ((coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[0], coords_view_to_region(bpy.context.area, tuple((lazy_c_gpu_draw_wrangler['sna_start_x'], lazy_c_gpu_draw_wrangler['sna_start_y'])))[1]), (coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0], coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]))
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", Color_1)
        bgl.glLineWidth(2.0)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glEnable(bgl.GL_LINE_SMOOTH)
        batch.draw(shader)


def sna_func_DEF24(Input, Input_001):
    sna_draw_rounded_box_first_2648C(2.0, Input, True)


class SNA_OT_Lazy_Join_2947E(bpy.types.Operator):
    bl_idname = "sna.lazy_join_2947e"
    bl_label = "Lazy Join"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] == None):
            pass
        else:
            if (lazy_c_gpu_draw_wrangler['sna_store_first_node'] == None):
                pass
            sna_check_socket_type_and_store_out_77CE8()
            sna_check_socket_type_and_store_in_D240E()
            if (property_exists("lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[0]", globals(), locals()) or property_exists("lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[0]", globals(), locals())):
                if (property_exists("sna_is_socket_free_out_E416E()", globals(), locals()) or property_exists("sna_is_socket_free_in_2E627()", globals(), locals())):
                    link_51A24 = bpy.context.area.spaces[0].node_tree.links.new(input=sna_is_socket_free_out_E416E(), output=sna_is_socket_free_in_2E627(), )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_mouse_over_node_select_4EE67(first_node):
    for i_39DC0 in range(len(bpy.context.area.spaces[0].node_tree.nodes)):
        if (((coords_view_to_region(bpy.context.area, tuple((bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location[0] + (bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[0] / bpy.context.preferences.system.ui_scale, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[1] / bpy.context.preferences.system.ui_scale)[0], 0.0)))[0] > coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0]) and (coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location))[0] < coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0])) and ((coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location))[1] > coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]) and (coords_view_to_region(bpy.context.area, tuple((0.0, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location[1] - (bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[0] / bpy.context.preferences.system.ui_scale, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[1] / bpy.context.preferences.system.ui_scale)[1])))[1] < coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]))):
            if first_node:
                lazy_c_gpu_draw_wrangler['sna_store_first_node'] = bpy.context.area.spaces[0].node_tree.nodes[i_39DC0]
            else:
                if (lazy_c_gpu_draw_wrangler['sna_store_first_node'] == bpy.context.area.spaces[0].node_tree.nodes[i_39DC0]):
                    pass
                else:
                    lazy_c_gpu_draw_wrangler['sna_store_second_node'] = bpy.context.area.spaces[0].node_tree.nodes[i_39DC0]
            return (((coords_view_to_region(bpy.context.area, tuple((bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location[0] + (bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[0] / bpy.context.preferences.system.ui_scale, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[1] / bpy.context.preferences.system.ui_scale)[0], 0.0)))[0] > coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0]) and (coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location))[0] < coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[0])) and ((coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location))[1] > coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1]) and (coords_view_to_region(bpy.context.area, tuple((0.0, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].location[1] - (bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[0] / bpy.context.preferences.system.ui_scale, bpy.context.area.spaces[0].node_tree.nodes[i_39DC0].dimensions[1] / bpy.context.preferences.system.ui_scale)[1])))[1] < coords_view_to_region(bpy.context.area, tuple(bpy.context.area.spaces[0].cursor_location))[1])))
        else:
            lazy_c_gpu_draw_wrangler['sna_store_second_node'] = None


def sna_is_socket_free_in_2E627():
    for i_084B4 in range(len(lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs.values())):
        if ((not lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_084B4].is_linked) if ('Compare' in sna_check_socket_type_and_store_in_D240E()[1] or 'BooleanMath' in sna_check_socket_type_and_store_in_D240E()[1] or 'Print' in sna_check_socket_type_and_store_in_D240E()[1] or 'VectorMath' in sna_check_socket_type_and_store_in_D240E()[1]) else ((not lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_084B4].is_linked) and (lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_084B4].bl_idname == sna_check_socket_type_and_store_out_77CE8()[0]))):
            break
    return lazy_c_gpu_draw_wrangler['sna_store_second_node'].inputs[i_084B4]


def sna_is_socket_free_out_E416E():
    for i_AC166 in range(len(lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs.values())):
        if ((not lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[i_AC166].is_linked) and (lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[i_AC166].bl_idname == sna_check_socket_type_and_store_in_D240E()[0])):
            break
    return lazy_c_gpu_draw_wrangler['sna_store_first_node'].outputs[i_AC166]


def sna_if_first_node_is_4B3B5():
    if (lazy_c_gpu_draw_wrangler['sna_store_second_node'] != None):
        lazy_c_gpu_draw_wrangler['sna_button_and_operator_link'] = (((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_ButtonNodeNew') and ((lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_OperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_ModalOperatorNode'))) or ((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_OnKeypressNode') and ((lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_MenuNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_OperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_ModalOperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_PanelNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_PieMenuNode'))) or ((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_RunFunctionNode') and (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_FunctionNode')) or ((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_RunInterfaceFunctionNodeNew') and (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_InterfaceFunctionNode')) or ((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_SubmenuNodeNew') and (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_MenuNode')) or ((lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_RunOperatorNode') and ((lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_OperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_second_node'].bl_idname == 'SN_ModalOperatorNode'))))
        return False
    else:
        lazy_c_gpu_draw_wrangler['sna_button_and_operator_link'] = (lazy_c_gpu_draw_wrangler['sna_store_first_node'].bl_idname == 'SN_ButtonNodeNew')


class SNA_OT_Lazy_Link_C08E5(bpy.types.Operator):
    bl_idname = "sna.lazy_link_c08e5"
    bl_label = "Lazy Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if ((lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_OperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_ModalOperatorNode')):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].source_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_OperatorNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_OperatorNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].parent_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].action = 'OPERATOR'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_OperatorNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_MenuNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].parent_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].action = 'MENU'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_MenuNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_PanelNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].parent_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].action = 'PANEL'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_PanelNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_PieMenuNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].parent_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].action = 'PIE_MENU'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_PieMenuNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_FunctionNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node']['ref_ntree'] = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_FunctionNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_InterfaceFunctionNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node']['ref_ntree'] = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_InterfaceFunctionNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_MenuNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_MenuNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if ((lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_OperatorNode') or (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_ModalOperatorNode')):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].source_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node']['ref_ntree'] = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_OperatorNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        if (lazy_c_gpu_draw_wrangler['sna_store_bl_idname_second_node'] == 'SN_ModalOperatorNode'):
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].parent_type = 'CUSTOM'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_ntree = bpy.context.area.spaces[0].node_tree
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].action = 'OPERATOR'
            lazy_c_gpu_draw_wrangler['sna_store_first_node'].ref_SN_OperatorNode = lazy_c_gpu_draw_wrangler['sna_store_name_second_node']
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_move_nodes_to_new_graph_DC18C(layout_function, ):
    op = layout_function.operator('sna.move_to_new_graph_1a51e', text='Move Nodes to New Graph', icon_value=414, emboss=True, depress=False)
    op = layout_function.operator('wm.call_panel', text='Move Nodes to Existing Graph', icon_value=414, emboss=True, depress=False)
    op.name = 'NODE_PT_move_to_graph'


class SNA_OT_Move_To_Existing_Graph_Cd53F(bpy.types.Operator):
    bl_idname = "sna.move_to_existing_graph_cd53f"
    bl_label = "move to existing graph"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.StringProperty(name='New Property', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if (len(bpy.context.selected_nodes) != 0):
            bpy.ops.node.clipboard_copy('INVOKE_DEFAULT', )
            bpy.ops.node.delete('INVOKE_DEFAULT', )
            for i_1B6D6 in range(len(bpy.data.node_groups)):
                if (bpy.data.node_groups[i_1B6D6].name == self.sna_new_property):
                    bpy.context.scene.sn.node_tree_index = i_1B6D6
                    bpy.ops.node.clipboard_paste('INVOKE_DEFAULT', )
                    bpy.ops.node.view_selected('INVOKE_DEFAULT', )
        else:
            bpy.ops.wm.call_panel('INVOKE_DEFAULT', name='NODE_PT_warning_move_to_graph')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class NODE_PT_move_to_graph(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'NODE_PT_move_to_graph'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Node Trees', icon_value=0)
        for i_2690F in range(len(bpy.data.node_groups)):
            if ('SCRIPTING' == bpy.data.node_groups[i_2690F].type):
                op = layout.operator('sna.move_to_existing_graph_cd53f', text=bpy.data.node_groups[i_2690F].name, icon_value=0, emboss=True, depress=False)
                op.sna_new_property = bpy.data.node_groups[i_2690F].name


class NODE_PT_warning_move_to_graph(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'NODE_PT_warning_move_to_graph'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Select Nodes to Move', icon_value=1)


class SNA_OT_Move_To_New_Graph_1A51E(bpy.types.Operator):
    bl_idname = "sna.move_to_new_graph_1a51e"
    bl_label = "move to new graph"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if (len(bpy.context.selected_nodes) != 0):
            bpy.ops.node.clipboard_copy('INVOKE_DEFAULT', )
            bpy.ops.node.delete('INVOKE_DEFAULT', )
            tree_87E15 = bpy.data.node_groups.new(name='', type='ScriptingNodesTree', )
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
            for i_C2599 in range(len(bpy.data.node_groups)):
                if (bpy.data.node_groups[i_C2599] == tree_87E15):
                    bpy.context.scene.sn.node_tree_index = i_C2599
                    bpy.ops.node.clipboard_paste('INVOKE_DEFAULT', )
                    bpy.ops.node.view_selected('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        bpy.ops.wm.call_panel('INVOKE_DEFAULT', name='NODE_PT_warning_move_to_graph')
        return self.execute(context)


class SNA_PT_NEW_PANEL_9A80E(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_9A80E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'New Category'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_F1963 = layout.row(heading='', align=True)
        row_F1963.alert = False
        row_F1963.enabled = True
        row_F1963.active = True
        row_F1963.use_property_split = False
        row_F1963.use_property_decorate = False
        row_F1963.scale_x = 1.0
        row_F1963.scale_y = 1.0
        row_F1963.alignment = 'Expand'.upper()
        row_F1963.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if bpy.context.active_node.bl_idname:
            row_F1963.prop(bpy.context.active_node, 'bl_idname', text='', icon_value=0, emboss=True)
            op = row_F1963.operator('sna.copy_blidname_02e6d', text='', icon_value=598, emboss=True, depress=False)


class SNA_OT_Copy_Blidname_02E6D(bpy.types.Operator):
    bl_idname = "sna.copy_blidname_02e6d"
    bl_label = "copy_blidname"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Copy_Node_Blidname_E6F8F(bpy.types.Operator):
    bl_idname = "sna.copy_node_blidname_e6f8f"
    bl_label = "copy_node_blidname"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.active_node:
            if bpy.context.active_node.bl_idname:
                bpy.context.window_manager.clipboard = bpy.context.active_node.bl_idname
                self.report({'INFO'}, message='Copied to Clipboard:   ' + bpy.context.window_manager.clipboard)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Select_Nodes_Only_71C7F(bpy.types.Operator):
    bl_idname = "sna.select_nodes_only_71c7f"
    bl_label = "Select Nodes Only"
    bl_description = "Selects unused nodes on the current graph"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        output_0_8abf8 = sna_unsed_nodes_61BC9(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_node_count_5C2CE():
    node_count['sna_node_count'] = 0
    for i_F8694 in range(len(bpy.data.node_groups)):
        if property_exists("bpy.data.node_groups[i_F8694].is_sn", globals(), locals()):
            node_count['sna_node_count'] += len(bpy.data.node_groups[i_F8694].nodes.values())
    return node_count['sna_node_count']


class SNA_OT_Select_And_Delete_Nodes_511Da(bpy.types.Operator):
    bl_idname = "sna.select_and_delete_nodes_511da"
    bl_label = "Select and Delete Nodes"
    bl_description = "Removes nodes that have no links from the current nodetree"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        for i_76B67 in range(len(bpy.context.area.spaces[0].node_tree.nodes)):
            if ((bpy.context.area.spaces[0].node_tree.nodes[i_76B67].bl_idname == 'NodeFrame') or (bpy.context.area.spaces[0].node_tree.nodes[i_76B67].bl_idname == 'SN_OnKeypressNode')):
                pass
            else:
                if bpy.context.area.spaces[0].node_tree.nodes[i_76B67].name in node_count['sna_to_from_nodes']:
                    pass
                else:
                    bpy.context.area.spaces[0].node_tree.nodes[i_76B67].select = True
        bpy.ops.node.delete('INVOKE_DEFAULT', )
        self.report({'INFO'}, message=str(len(node_count['sna_unused_count'])) + ' Unused Node(s) Removed')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_unsed_nodes_61BC9(Select):
    node_count['sna_to_from_nodes'] = []
    node_count['sna_unused_count'] = []
    for i_98B89 in range(len(bpy.context.area.spaces[0].node_tree.links)):
        node_count['sna_to_from_nodes'].append(bpy.context.area.spaces[0].node_tree.links[i_98B89].from_node.name)
    for i_5EE69 in range(len(bpy.context.area.spaces[0].node_tree.links)):
        node_count['sna_to_from_nodes'].append(bpy.context.area.spaces[0].node_tree.links[i_5EE69].to_node.name)
    for i_E945E in range(len(bpy.context.area.spaces[0].node_tree.nodes)):
        if ((bpy.context.area.spaces[0].node_tree.nodes[i_E945E].bl_idname == 'NodeFrame') or (bpy.context.area.spaces[0].node_tree.nodes[i_E945E].bl_idname == 'SN_OnKeypressNode') or ('NodeReroute' == bpy.context.area.spaces[0].node_tree.nodes[i_E945E].bl_idname)):
            pass
        else:
            if bpy.context.area.spaces[0].node_tree.nodes[i_E945E].name in node_count['sna_to_from_nodes']:
                pass
            else:
                node_count['sna_unused_count'].append(bpy.context.area.spaces[0].node_tree.nodes[i_E945E].name)
    if Select:
        for i_718EB in range(len(node_count['sna_unused_count'])):
            bpy.context.area.spaces[0].node_tree.nodes[node_count['sna_unused_count'][i_718EB]].select = True
    else:
        return len(node_count['sna_unused_count'])


def sna_add_to_sn_pt_graphpanel_BEC15(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_settings__show_node_count:
            if (property_exists("bpy.context.area.spaces[0].node_tree.links", globals(), locals()) and property_exists("bpy.context.area.spaces[0].node_tree.nodes", globals(), locals()) and property_exists("bpy.context.area.spaces[0].node_tree.nodes", globals(), locals())):
                col_0A0D0 = layout.column(heading='', align=True)
                col_0A0D0.alert = False
                col_0A0D0.enabled = True
                col_0A0D0.active = True
                col_0A0D0.use_property_split = False
                col_0A0D0.use_property_decorate = False
                col_0A0D0.scale_x = 1.0
                col_0A0D0.scale_y = 1.0
                col_0A0D0.alignment = 'Expand'.upper()
                col_0A0D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                box_51BAF = col_0A0D0.box()
                box_51BAF.alert = False
                box_51BAF.enabled = True
                box_51BAF.active = True
                box_51BAF.use_property_split = False
                box_51BAF.use_property_decorate = False
                box_51BAF.alignment = 'Expand'.upper()
                box_51BAF.scale_x = 1.0
                box_51BAF.scale_y = 1.0
                box_51BAF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_F0837 = box_51BAF.column(heading='', align=True)
                col_F0837.alert = False
                col_F0837.enabled = True
                col_F0837.active = True
                col_F0837.use_property_split = False
                col_F0837.use_property_decorate = False
                col_F0837.scale_x = 1.0
                col_F0837.scale_y = 1.0
                col_F0837.alignment = 'Expand'.upper()
                col_F0837.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_BDD4D = col_F0837.row(heading='', align=False)
                row_BDD4D.alert = False
                row_BDD4D.enabled = True
                row_BDD4D.active = True
                row_BDD4D.use_property_split = False
                row_BDD4D.use_property_decorate = False
                row_BDD4D.scale_x = 1.0
                row_BDD4D.scale_y = 1.0
                row_BDD4D.alignment = 'Left'.upper()
                row_BDD4D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_BDD4D.label(text='Total Node Count:', icon_value=0)
                row_BDD4D.label(text=str(sna_node_count_5C2CE()), icon_value=0)
                split_C9C89 = col_F0837.split(factor=0.7275680899620056, align=False)
                split_C9C89.alert = False
                split_C9C89.enabled = True
                split_C9C89.active = True
                split_C9C89.use_property_split = False
                split_C9C89.use_property_decorate = False
                split_C9C89.scale_x = 1.0
                split_C9C89.scale_y = 1.0
                split_C9C89.alignment = 'Expand'.upper()
                split_C9C89.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_BCED4 = split_C9C89.row(heading='', align=False)
                row_BCED4.alert = False
                row_BCED4.enabled = True
                row_BCED4.active = True
                row_BCED4.use_property_split = False
                row_BCED4.use_property_decorate = False
                row_BCED4.scale_x = 1.0
                row_BCED4.scale_y = 1.0
                row_BCED4.alignment = 'Left'.upper()
                row_BCED4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_BCED4.label(text='Unused Nodes on Graph:', icon_value=0)
                row_BCED4.label(text=str(sna_unsed_nodes_61BC9(False)), icon_value=0)
                row_44DC8 = split_C9C89.row(heading='', align=True)
                row_44DC8.alert = False
                row_44DC8.enabled = True
                row_44DC8.active = True
                row_44DC8.use_property_split = False
                row_44DC8.use_property_decorate = False
                row_44DC8.scale_x = 1.0
                row_44DC8.scale_y = 1.0
                row_44DC8.alignment = 'Right'.upper()
                row_44DC8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_44DC8.operator('sna.select_nodes_only_71c7f', text='', icon_value=256, emboss=True, depress=False)
                op = row_44DC8.operator('sna.select_and_delete_nodes_511da', text='', icon_value=21, emboss=True, depress=False)


class SNA_PT_SERPENS_NODE_WRANGLER_9F143(bpy.types.Panel):
    bl_label = 'Serpens Node Wrangler'
    bl_idname = 'SNA_PT_SERPENS_NODE_WRANGLER_9F143'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Serpens Node Wrangler'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.area.ui_type == 'ScriptingNodesTree')))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_8D84A = layout.box()
        box_8D84A.alert = False
        box_8D84A.enabled = True
        box_8D84A.active = True
        box_8D84A.use_property_split = False
        box_8D84A.use_property_decorate = False
        box_8D84A.alignment = 'Expand'.upper()
        box_8D84A.scale_x = 1.0
        box_8D84A.scale_y = 1.0
        box_8D84A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_D4D8D = box_8D84A.column(heading='', align=True)
        col_D4D8D.alert = False
        col_D4D8D.enabled = True
        col_D4D8D.active = True
        col_D4D8D.use_property_split = False
        col_D4D8D.use_property_decorate = False
        col_D4D8D.scale_x = 1.0
        col_D4D8D.scale_y = 1.0
        col_D4D8D.alignment = 'Expand'.upper()
        col_D4D8D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_A320C = col_D4D8D.column(heading='', align=False)
        col_A320C.alert = False
        col_A320C.enabled = True
        col_A320C.active = True
        col_A320C.use_property_split = False
        col_A320C.use_property_decorate = False
        col_A320C.scale_x = 1.0
        col_A320C.scale_y = 1.0
        col_A320C.alignment = 'Expand'.upper()
        col_A320C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_A320C.label(text='Serpens Wrangler Panel', icon_value=0)
        col_A320C.prop(find_user_keyconfig('B6E32'), 'type', text='', full_event=True)
        col_D4D8D.separator(factor=3.549999952316284)
        col_D4D8D.prop(bpy.context.scene, 'sna_settings__show_node_count', text='Show Node Count', icon_value=0, emboss=True)
        col_D4D8D.prop(bpy.context.scene, 'sna_showdatapaths', text='Show Data Paths for Blend Data Browser Nodes', icon_value=0, emboss=True)
        col_D4D8D.prop(bpy.context.scene, 'sna_datapathstextsize', text='Data Path Text Size', icon_value=0, emboss=True)
        col_D4D8D.prop(bpy.context.scene, 'sna_propertiespanel_getset', text='Show Properties Get & Set Shortcuts', icon_value=0, emboss=True)
        col_D4D8D.separator(factor=4.0)
        col_D4D8D.prop(bpy.context.scene, 'sna_lazy_connect_color', text='Lazy Connect', icon_value=0, emboss=True)
        col_D4D8D.prop(find_user_keyconfig('CAC5B'), 'type', text='', full_event=True)
        col_D4D8D.prop(bpy.context.scene, 'sna_lazy_compare_color', text='Lazy Compare', icon_value=0, emboss=True)
        col_D4D8D.prop(find_user_keyconfig('B4BF4'), 'type', text='', full_event=True)
        col_D4D8D.prop(bpy.context.scene, 'sna_lazy_link_color', text='Lazy Link', icon_value=0, emboss=True)
        col_D4D8D.prop(find_user_keyconfig('CAC5B'), 'type', text='', full_event=True)
        col_D4D8D.separator(factor=5.0)
        col_0515C = col_D4D8D.column(heading='', align=True)
        col_0515C.alert = False
        col_0515C.enabled = True
        col_0515C.active = True
        col_0515C.use_property_split = False
        col_0515C.use_property_decorate = False
        col_0515C.scale_x = 1.0
        col_0515C.scale_y = 1.0
        col_0515C.alignment = 'Expand'.upper()
        col_0515C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_0515C.label(text='Copy Node Bl_Idname', icon_value=0)
        col_0515C.prop(find_user_keyconfig('5CFB0'), 'type', text='', full_event=True)
        col_38C0E = col_D4D8D.column(heading='', align=True)
        col_38C0E.alert = False
        col_38C0E.enabled = True
        col_38C0E.active = True
        col_38C0E.use_property_split = False
        col_38C0E.use_property_decorate = False
        col_38C0E.scale_x = 1.0
        col_38C0E.scale_y = 1.0
        col_38C0E.alignment = 'Expand'.upper()
        col_38C0E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_38C0E.label(text='Clear All Print Nodes', icon_value=0)
        col_38C0E.prop(find_user_keyconfig('1DA59'), 'type', text='', full_event=True)
        col_D92C5 = col_D4D8D.column(heading='', align=True)
        col_D92C5.alert = False
        col_D92C5.enabled = True
        col_D92C5.active = True
        col_D92C5.use_property_split = False
        col_D92C5.use_property_decorate = False
        col_D92C5.scale_x = 1.0
        col_D92C5.scale_y = 1.0
        col_D92C5.alignment = 'Expand'.upper()
        col_D92C5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_D92C5.label(text='Show Run Script Node in Text Editor', icon_value=0)
        col_D92C5.prop(find_user_keyconfig('04B86'), 'type', text='', full_event=True)
        col_04063 = col_D4D8D.column(heading='', align=True)
        col_04063.alert = False
        col_04063.enabled = True
        col_04063.active = True
        col_04063.use_property_split = False
        col_04063.use_property_decorate = False
        col_04063.scale_x = 1.0
        col_04063.scale_y = 1.0
        col_04063.alignment = 'Expand'.upper()
        col_04063.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_04063.label(text='Update Run Script Nodes', icon_value=0)
        col_04063.prop(find_user_keyconfig('B8630'), 'type', text='', full_event=True)


class SNA_OT_Add_Function_Dce29(bpy.types.Operator):
    bl_idname = "sna.add_function_dce29"
    bl_label = "add_function"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        node_A1A0E = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_FunctionNode', )
        node_A1A0E.location = bpy.context.area.spaces[0].cursor_location
        node_6DBBB = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_RunFunctionNode', )
        node_6DBBB.location = (node_A1A0E.location[0] + -300.0, node_A1A0E.location[1])
        node_835FD = bpy.context.area.spaces[0].node_tree.nodes.new(type='SN_FunctionReturnNode', )
        node_835FD.location = (node_A1A0E.location[0] + 600.0, node_A1A0E.location[1])
        link_CC24B = bpy.context.area.spaces[0].node_tree.links.new(input=node_835FD.inputs[0], output=node_A1A0E.outputs[0], )
        for i_C754C in range(len(bpy.context.selected_nodes)):
            if bpy.context.selected_nodes[i_C754C].bl_rna.identifier == 'SN_RunFunctionNode':
                bpy.context.area.spaces[0].node_tree.nodes.active = bpy.context.selected_nodes[i_C754C]
                if bpy.context and bpy.context.screen:
                    for a in bpy.context.screen.areas:
                        a.tag_redraw()
                bpy.context.active_node.ref_ntree = bpy.context.area.spaces[0].node_tree
                for i_A8DD6 in range(len(bpy.context.selected_nodes)):
                    if bpy.context.selected_nodes[i_A8DD6].bl_rna.identifier == 'SN_FunctionNode':
                        bpy.context.active_node.ref_SN_FunctionNode = bpy.context.selected_nodes[i_A8DD6].name
                        for i_716D4 in range(len(bpy.context.selected_nodes)):
                            if bpy.context.selected_nodes[i_716D4].bl_rna.identifier == 'SN_FunctionReturnNode':
                                bpy.context.active_node.ref_SN_FunctionReturnNode = bpy.context.selected_nodes[i_716D4].name
                                bpy.ops.transform.translate('INVOKE_DEFAULT', )
                        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_quick_function_B0B9F(layout_function, ):
    op = layout_function.operator('sna.add_function_dce29', text='Quick Function', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)


class SNA_OT_Quick_Interface_Function_F937A(bpy.types.Operator):
    bl_idname = "sna.quick_interface_function_f937a"
    bl_label = "Quick_Interface_Function"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        created_node_0_7a8e6 = sna_create_node_mouse_loc_6399A_7A8E6('SN_RunInterfaceFunctionNode', '')
        created_node_0_1f621 = sna_create_node_offset_to_node_loc_253EE_1F621('SN_InterfaceFunctionNode', '', 250.0, 0.0)
        for i_2A882 in range(len(bpy.context.selected_nodes)):
            if (bpy.context.selected_nodes[i_2A882].bl_idname == 'SN_InterfaceFunctionNode'):
                quick_interface_function['sna_quick_store_interfacefunction'] = bpy.context.selected_nodes[i_2A882].name
        for i_2596D in range(len(bpy.context.selected_nodes)):
            if (bpy.context.selected_nodes[i_2596D].bl_idname == 'SN_RunInterfaceFunctionNode'):
                bpy.context.selected_nodes[i_2596D].ref_ntree = bpy.context.area.spaces[0].node_tree
                bpy.context.selected_nodes[i_2596D].ref_SN_InterfaceFunctionNode = quick_interface_function['sna_quick_store_interfacefunction']
        bpy.ops.transform.translate('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_quick_interface_function_D9DDB(layout_function, ):
    op = layout_function.operator('sna.quick_interface_function_f937a', text='Quick Interface Function', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)


class SNA_OT_Print_Forloop_C05Db(bpy.types.Operator):
    bl_idname = "sna.print_forloop_c05db"
    bl_label = "print_forloop"
    bl_description = "Select a node to quickly print in a for-loop"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        quick_print['sna_storeactnode'] = None
        quick_print['sna_storeactnode'] = bpy.context.active_node
        node_0_b8502 = sna_create_node_at_mouse_location_C6B17_B8502('SN_TriggerNode', False, 0.0, 0.0)
        node_0_b8502.location = (quick_print['sna_storeactnode'].location[0], quick_print['sna_storeactnode'].location[1] + node_0_b8502.height + 10.0)
        node_0_a4c01 = sna_create_node_at_mouse_location_C6B17_A4C01('SN_ForExecuteNode', False, 0.0, 0.0)
        node_0_a4c01.location = (quick_print['sna_storeactnode'].location[0] + node_0_a4c01.width + 50.0, quick_print['sna_storeactnode'].location[1] + 100.0)
        node_0_59149 = sna_create_node_at_mouse_location_C6B17_59149('SN_PrintNode', False, 0.0, 0.0)
        node_0_59149.location = (quick_print['sna_storeactnode'].location[0] + node_0_59149.width + 450.0, quick_print['sna_storeactnode'].location[1] + 100.0)
        link_6C43F = bpy.context.area.spaces[0].node_tree.links.new(input=node_0_b8502.outputs[0], output=node_0_a4c01.inputs[0], )
        link_D5933 = bpy.context.area.spaces[0].node_tree.links.new(input=node_0_a4c01.outputs[0], output=node_0_59149.inputs[0], )
        link_B73F0 = bpy.context.area.spaces[0].node_tree.links.new(input=quick_print['sna_storeactnode'].outputs[1], output=node_0_a4c01.inputs[1], )
        link_74310 = bpy.context.area.spaces[0].node_tree.links.new(input=node_0_a4c01.outputs[2], output=node_0_59149.inputs[1], )
        if (quick_print['sna_storeactnode'].outputs[1].data_type == 'SN_ListSocket'):
            node_0_a4c01.for_type = 'List'
            node_0_59149.width = 400.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Quick_Print_1Ba7A(bpy.types.Operator):
    bl_idname = "sna.quick_print_1ba7a"
    bl_label = "quick_print"
    bl_description = "Select a node to quickly print"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if (len(bpy.context.active_node.outputs.values()) == 1):
            quick_print['sna_storeactnode'] = None
            quick_print['sna_storeactnode'] = bpy.context.active_node
            node_0_e6251 = sna_create_node_at_mouse_location_C6B17_E6251('SN_TriggerNode', False, 0.0, 0.0)
            node_0_e6251.location = (quick_print['sna_storeactnode'].location[0], quick_print['sna_storeactnode'].location[1] + node_0_e6251.height + 10.0)
            node_0_afc6d = sna_create_node_at_mouse_location_C6B17_AFC6D('SN_PrintNode', False, 0.0, 0.0)
            node_0_afc6d.location = (quick_print['sna_storeactnode'].location[0] + node_0_afc6d.width + 100.0, quick_print['sna_storeactnode'].location[1] + 100.0)
            link_CD5DA = bpy.context.area.spaces[0].node_tree.links.new(input=node_0_e6251.outputs[0], output=node_0_afc6d.inputs[0], )
            link_01CB0 = bpy.context.area.spaces[0].node_tree.links.new(input=quick_print['sna_storeactnode'].outputs[0], output=node_0_afc6d.inputs[1], )
            node_0_afc6d.width = 400.0
        else:
            quick_print['sna_storeactnode'] = None
            quick_print['sna_storeactnode'] = bpy.context.active_node
            node_0_6a345 = sna_create_node_at_mouse_location_C6B17_6A345('SN_TriggerNode', False, 0.0, 0.0)
            node_0_6a345.location = (quick_print['sna_storeactnode'].location[0], quick_print['sna_storeactnode'].location[1] + node_0_6a345.height + 10.0)
            node_0_32d85 = sna_create_node_at_mouse_location_C6B17_32D85('SN_PrintNode', False, 0.0, 0.0)
            node_0_32d85.location = (quick_print['sna_storeactnode'].location[0] + node_0_32d85.width + 100.0, quick_print['sna_storeactnode'].location[1] + 100.0)
            link_B79B7 = bpy.context.area.spaces[0].node_tree.links.new(input=node_0_6a345.outputs[0], output=node_0_32d85.inputs[0], )
            link_DC27D = bpy.context.area.spaces[0].node_tree.links.new(input=quick_print['sna_storeactnode'].outputs[1], output=node_0_32d85.inputs[1], )
            node_0_32d85.width = 400.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_quick_print_09698(layout_function, ):
    if bpy.context.active_node:
        op = layout_function.operator('sna.quick_print_1ba7a', text='Quick Print', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)
    else:
        row_321C2 = layout_function.row(heading='', align=False)
        row_321C2.alert = False
        row_321C2.enabled = False
        row_321C2.active = False
        row_321C2.use_property_split = False
        row_321C2.use_property_decorate = False
        row_321C2.scale_x = 1.0
        row_321C2.scale_y = 1.0
        row_321C2.alignment = 'Expand'.upper()
        row_321C2.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_321C2.operator('sna.quick_print_1ba7a', text='Quick Print', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)
    if ((len(bpy.context.selected_nodes) > 0) and (len(bpy.context.selected_nodes) < 2)):
        op = layout_function.operator('sna.print_forloop_c05db', text='Quick Print ForLoop ', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)
    else:
        row_6144E = layout_function.row(heading='', align=False)
        row_6144E.alert = False
        row_6144E.enabled = False
        row_6144E.active = False
        row_6144E.use_property_split = False
        row_6144E.use_property_decorate = False
        row_6144E.scale_x = 1.0
        row_6144E.scale_y = 1.0
        row_6144E.alignment = 'Expand'.upper()
        row_6144E.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        op = row_6144E.operator('sna.print_forloop_c05db', text='Quick Print ForLoop ', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'quick3.png')), emboss=True, depress=False)


class SNA_OT_Update_Run_Script_Nodes_732Bd(bpy.types.Operator):
    bl_idname = "sna.update_run_script_nodes_732bd"
    bl_label = "Update Run Script Nodes"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_E33E1 in range(len(bpy.data.node_groups)):
            for i_1F1FA in range(len(bpy.data.node_groups[i_E33E1].nodes)):
                if ('SN_RunScriptNode' == bpy.data.node_groups[i_E33E1].nodes[i_1F1FA].bl_idname):
                    if (bpy.data.node_groups[i_E33E1].nodes[i_1F1FA].script == bpy.context.area.spaces[0].text):
                        bpy.ops.sn.reload_script('INVOKE_DEFAULT', node=bpy.data.node_groups[i_E33E1].nodes[i_1F1FA].name, node_tree=bpy.data.node_groups[i_E33E1].name)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_text_mt_editor_menus_8ACED(self, context):
    if not (False):
        layout = self.layout
        layout.separator(factor=1.0)
        op = layout.operator('sna.update_run_script_nodes_732bd', text='Update Run Script Nodes', icon_value=692, emboss=True, depress=False)


class SNA_OT_Show_Run_Script_Text001_D4523(bpy.types.Operator):
    bl_idname = "sna.show_run_script_text001_d4523"
    bl_label = "Show Run Script Text.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_01E97 in range(len(bpy.context.screen.areas)):
            if (bpy.context.screen.areas[i_01E97].ui_type == 'TEXT_EDITOR'):
                bpy.context.screen.areas[i_01E97].spaces[0].text = bpy.context.active_node.script
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_NEW_PANEL_0D70C(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_0D70C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=12

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.area.ui_type == 'ScriptingNodesTree')))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Serpens Wrangler Panel', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'serps5.png')))
        box_95DF3 = layout.box()
        box_95DF3.alert = False
        box_95DF3.enabled = True
        box_95DF3.active = True
        box_95DF3.use_property_split = False
        box_95DF3.use_property_decorate = False
        box_95DF3.alignment = 'Expand'.upper()
        box_95DF3.scale_x = 1.0
        box_95DF3.scale_y = 1.0
        box_95DF3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        layout_function = box_95DF3
        sna_find_nodes_B70F8(layout_function, )
        layout_function = box_95DF3
        sna_find_uid_F54AB(layout_function, )
        box_5DD06 = layout.box()
        box_5DD06.alert = False
        box_5DD06.enabled = True
        box_5DD06.active = True
        box_5DD06.use_property_split = False
        box_5DD06.use_property_decorate = False
        box_5DD06.alignment = 'Expand'.upper()
        box_5DD06.scale_x = 1.0
        box_5DD06.scale_y = 1.0
        box_5DD06.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        grid_7E6F4 = box_5DD06.grid_flow(columns=2, row_major=False, even_columns=False, even_rows=False, align=False)
        grid_7E6F4.enabled = True
        grid_7E6F4.active = True
        grid_7E6F4.use_property_split = False
        grid_7E6F4.use_property_decorate = False
        grid_7E6F4.alignment = 'Expand'.upper()
        grid_7E6F4.scale_x = 1.0
        grid_7E6F4.scale_y = 1.0
        grid_7E6F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        grid_7E6F4.prop(bpy.context.scene.sn, 'debug_python_nodes', text='Debug Nodes', icon_value=0, emboss=True)
        if property_exists("bpy.context.scene.sn.debug_selected_only", globals(), locals()):
            grid_7E6F4.prop(bpy.context.scene.sn, 'debug_selected_only', text='Debug Selected Node', icon_value=0, emboss=True)
        grid_7E6F4.prop(bpy.context.scene.sn, 'debug_python_sockets', text='Debug Sockets', icon_value=0, emboss=True)
        grid_7E6F4.prop(bpy.context.scene.sn, 'debug_code', text='Keep Code File', icon_value=0, emboss=True)
        box_21ADB = layout.box()
        box_21ADB.alert = False
        box_21ADB.enabled = True
        box_21ADB.active = True
        box_21ADB.use_property_split = False
        box_21ADB.use_property_decorate = False
        box_21ADB.alignment = 'Expand'.upper()
        box_21ADB.scale_x = 1.0
        box_21ADB.scale_y = 1.0
        box_21ADB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_9B660 = box_21ADB.column(heading='', align=True)
        col_9B660.alert = False
        col_9B660.enabled = True
        col_9B660.active = True
        col_9B660.use_property_split = False
        col_9B660.use_property_decorate = False
        col_9B660.scale_x = 1.0
        col_9B660.scale_y = 1.0
        col_9B660.alignment = 'Expand'.upper()
        col_9B660.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        layout_function = col_9B660
        sna_clean_sockets_ADA06(layout_function, )
        col_9B660.separator(factor=1.0)
        layout_function = col_9B660
        sna_create_button_4_op_3081B(layout_function, )
        layout_function = col_9B660
        sna_create_run_operator_FC5F3(layout_function, )
        layout_function = col_9B660
        sna_get_full_operator_4BA5D(layout_function, )
        col_9B660.separator(factor=1.0)
        layout_function = col_9B660
        sna_create_operator_for_button_2723E(layout_function, )
        col_9B660.separator(factor=1.0)
        layout_function = col_9B660
        sna_quick_print_09698(layout_function, )
        layout_function = col_9B660
        sna_quick_function_B0B9F(layout_function, )
        layout_function = col_9B660
        sna_quick_interface_function_D9DDB(layout_function, )
        layout_function = col_9B660
        sna_keypress_operator_C5375(layout_function, )
        layout_function = col_9B660
        sna_clear_all_print_nodes001_52173(layout_function, )
        col_9B660.separator(factor=1.0)
        layout_function = col_9B660
        sna_move_nodes_to_new_graph_DC18C(layout_function, )


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_find_uid = bpy.props.StringProperty(name='find_UID', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_settings__show_node_count = bpy.props.BoolProperty(name='SETTINGS - Show Node Count', description='', default=True)
    bpy.types.Scene.sna_lazy_connect_color = bpy.props.FloatVectorProperty(name='Lazy Connect Color', description='', size=4, default=(0.28159698843955994, 1.0, 0.6424620151519775, 0.47902101278305054), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_lazy_link_color = bpy.props.FloatVectorProperty(name='Lazy Link Color', description='', size=4, default=(1.0, 1.0, 1.0, 0.330130010843277), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_lazy_compare_color = bpy.props.FloatVectorProperty(name='Lazy Compare Color', description='', size=4, default=(0.7369359731674194, 0.2857080101966858, 0.353875994682312, 0.7897149920463562), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_lazy_blank_color = bpy.props.FloatVectorProperty(name='Lazy Blank Color', description='', size=4, default=(0.39649200439453125, 0.39649200439453125, 0.39649200439453125, 0.5973389744758606), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    bpy.types.Scene.sna_findnodes_stringinput = bpy.props.StringProperty(name='findnodes_stringinput', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_keypress_key = bpy.props.StringProperty(name='Keypress Key', description='', default='SLASH', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_keypress_shift = bpy.props.BoolProperty(name='Keypress Shift', description='', default=True)
    bpy.types.Scene.sna_keypress_ctrl = bpy.props.BoolProperty(name='Keypress Ctrl', description='', default=False)
    bpy.types.Scene.sna_keypress_alt = bpy.props.BoolProperty(name='Keypress Alt', description='', default=False)
    bpy.types.Scene.sna_showdatapaths = bpy.props.BoolProperty(name='ShowDataPaths', description='', default=False, update=sna_update_sna_showdatapaths_AD6AF)
    bpy.types.Scene.sna_datapathstextsize = bpy.props.FloatProperty(name='DataPathsTextSize', description='', default=11.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_propertiespanel_getset = bpy.props.BoolProperty(name='Propertiespanel_getset', description='', default=True)
    bpy.utils.register_class(SNA_OT_Modal_Operator_19F48)
    bpy.types.SN_PT_PropertyPanel.prepend(sna_add_to_sn_pt_propertypanel_7EB2D)
    bpy.utils.register_class(SNA_OT_Remove_Unused_Sockets_D0Ad5)
    bpy.utils.register_class(SNA_OT_Clear_All_Print_Nodes_133D5)
    bpy.utils.register_class(SNA_OT_Create_Button_4_Op_9C3Eb)
    bpy.utils.register_class(SNA_OT_Create_Operator_For_Button_Op_D1E5A)
    bpy.utils.register_class(SNA_OT_Cloneop_343Ed)
    bpy.utils.register_class(SNA_OT_Buttonop_F04Db)
    bpy.utils.register_class(SNA_OT_Runop_46D45)
    bpy.utils.register_class(SNA_OT_Find_Uid_0706D)
    bpy.utils.register_class(SNA_OT_Operator_62639)
    bpy.utils.register_class(NODE_PT_searchnodes)
    bpy.utils.register_class(SNA_OT_Get_Full_Operator_182B8)
    bpy.utils.register_class(SNA_OT_Modal_Operator_B6298)
    bpy.utils.register_class(SNA_OT_Graph_Label_Op_Cba49)
    bpy.utils.register_class(CRZ_PT_keypressoperator)
    bpy.utils.register_class(SNA_OT_Keypress_Operator001_18Cc9)
    bpy.utils.register_class(SNA_OT_Lazy_Modal_2B170)
    bpy.utils.register_class(SNA_OT_Lazy_Node_Detect_04D4C)
    bpy.utils.register_class(SNA_OT_Lazy_Nodes_Detect_1C7Ca)
    bpy.utils.register_class(SNA_OT_Lazy_Compare_Bf0Ca)
    bpy.utils.register_class(SNA_OT_Lazy_Join_2947E)
    bpy.utils.register_class(SNA_OT_Lazy_Link_C08E5)
    bpy.utils.register_class(SNA_OT_Move_To_Existing_Graph_Cd53F)
    bpy.utils.register_class(NODE_PT_move_to_graph)
    bpy.utils.register_class(NODE_PT_warning_move_to_graph)
    bpy.utils.register_class(SNA_OT_Move_To_New_Graph_1A51E)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_9A80E)
    bpy.utils.register_class(SNA_OT_Copy_Blidname_02E6D)
    bpy.utils.register_class(SNA_OT_Copy_Node_Blidname_E6F8F)
    bpy.utils.register_class(SNA_OT_Select_Nodes_Only_71C7F)
    bpy.utils.register_class(SNA_OT_Select_And_Delete_Nodes_511Da)
    bpy.types.SN_PT_GraphPanel.prepend(sna_add_to_sn_pt_graphpanel_BEC15)
    bpy.utils.register_class(SNA_PT_SERPENS_NODE_WRANGLER_9F143)
    bpy.utils.register_class(SNA_OT_Add_Function_Dce29)
    bpy.utils.register_class(SNA_OT_Quick_Interface_Function_F937A)
    bpy.utils.register_class(SNA_OT_Print_Forloop_C05Db)
    bpy.utils.register_class(SNA_OT_Quick_Print_1Ba7A)
    bpy.utils.register_class(SNA_OT_Update_Run_Script_Nodes_732Bd)
    bpy.types.TEXT_MT_editor_menus.append(sna_add_to_text_mt_editor_menus_8ACED)
    bpy.utils.register_class(SNA_OT_Show_Run_Script_Text001_D4523)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_0D70C)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.clear_all_print_nodes_133d5', 'C', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['1DA59'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.cloneop_343ed', 'O', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['BE37F'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    kmi = km.keymap_items.new('sna.lazy_node_detect_04d4c', 'RIGHTMOUSE', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['CAC5B'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    kmi = km.keymap_items.new('sna.lazy_nodes_detect_1c7ca', 'RIGHTMOUSE', 'PRESS',
        ctrl=True, alt=False, shift=True, repeat=False)
    addon_keymaps['B4BF4'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.copy_node_blidname_e6f8f', 'C', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    addon_keymaps['5CFB0'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.update_run_script_nodes_732bd', 'R', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['B8630'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.show_run_script_text001_d4523', 'LEFTMOUSE', 'DOUBLE_CLICK',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['04B86'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
    kmi = km.keymap_items.new('wm.call_panel', 'TAB', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_PT_NEW_PANEL_0D70C'
    kmi.properties.keep_open = False
    addon_keymaps['B6E32'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_propertiespanel_getset
    del bpy.types.Scene.sna_datapathstextsize
    del bpy.types.Scene.sna_showdatapaths
    del bpy.types.Scene.sna_keypress_alt
    del bpy.types.Scene.sna_keypress_ctrl
    del bpy.types.Scene.sna_keypress_shift
    del bpy.types.Scene.sna_keypress_key
    del bpy.types.Scene.sna_findnodes_stringinput
    del bpy.types.Scene.sna_lazy_blank_color
    del bpy.types.Scene.sna_lazy_compare_color
    del bpy.types.Scene.sna_lazy_link_color
    del bpy.types.Scene.sna_lazy_connect_color
    del bpy.types.Scene.sna_settings__show_node_count
    del bpy.types.Scene.sna_find_uid
    bpy.utils.unregister_class(SNA_OT_Modal_Operator_19F48)
    bpy.types.SN_PT_PropertyPanel.remove(sna_add_to_sn_pt_propertypanel_7EB2D)
    bpy.utils.unregister_class(SNA_OT_Remove_Unused_Sockets_D0Ad5)
    bpy.utils.unregister_class(SNA_OT_Clear_All_Print_Nodes_133D5)
    bpy.utils.unregister_class(SNA_OT_Create_Button_4_Op_9C3Eb)
    bpy.utils.unregister_class(SNA_OT_Create_Operator_For_Button_Op_D1E5A)
    bpy.utils.unregister_class(SNA_OT_Cloneop_343Ed)
    bpy.utils.unregister_class(SNA_OT_Buttonop_F04Db)
    bpy.utils.unregister_class(SNA_OT_Runop_46D45)
    if handler_B13A0:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_B13A0[0], 'WINDOW')
        handler_B13A0.pop(0)
    bpy.utils.unregister_class(SNA_OT_Find_Uid_0706D)
    bpy.utils.unregister_class(SNA_OT_Operator_62639)
    bpy.utils.unregister_class(NODE_PT_searchnodes)
    bpy.utils.unregister_class(SNA_OT_Get_Full_Operator_182B8)
    bpy.utils.unregister_class(SNA_OT_Modal_Operator_B6298)
    bpy.utils.unregister_class(SNA_OT_Graph_Label_Op_Cba49)
    bpy.utils.unregister_class(CRZ_PT_keypressoperator)
    bpy.utils.unregister_class(SNA_OT_Keypress_Operator001_18Cc9)
    bpy.utils.unregister_class(SNA_OT_Lazy_Modal_2B170)
    if handler_37344:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handler_37344[0], 'WINDOW')
        handler_37344.pop(0)
    bpy.utils.unregister_class(SNA_OT_Lazy_Node_Detect_04D4C)
    bpy.utils.unregister_class(SNA_OT_Lazy_Nodes_Detect_1C7Ca)
    bpy.utils.unregister_class(SNA_OT_Lazy_Compare_Bf0Ca)
    bpy.utils.unregister_class(SNA_OT_Lazy_Join_2947E)
    bpy.utils.unregister_class(SNA_OT_Lazy_Link_C08E5)
    bpy.utils.unregister_class(SNA_OT_Move_To_Existing_Graph_Cd53F)
    bpy.utils.unregister_class(NODE_PT_move_to_graph)
    bpy.utils.unregister_class(NODE_PT_warning_move_to_graph)
    bpy.utils.unregister_class(SNA_OT_Move_To_New_Graph_1A51E)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_9A80E)
    bpy.utils.unregister_class(SNA_OT_Copy_Blidname_02E6D)
    bpy.utils.unregister_class(SNA_OT_Copy_Node_Blidname_E6F8F)
    bpy.utils.unregister_class(SNA_OT_Select_Nodes_Only_71C7F)
    bpy.utils.unregister_class(SNA_OT_Select_And_Delete_Nodes_511Da)
    bpy.types.SN_PT_GraphPanel.remove(sna_add_to_sn_pt_graphpanel_BEC15)
    bpy.utils.unregister_class(SNA_PT_SERPENS_NODE_WRANGLER_9F143)
    bpy.utils.unregister_class(SNA_OT_Add_Function_Dce29)
    bpy.utils.unregister_class(SNA_OT_Quick_Interface_Function_F937A)
    bpy.utils.unregister_class(SNA_OT_Print_Forloop_C05Db)
    bpy.utils.unregister_class(SNA_OT_Quick_Print_1Ba7A)
    bpy.utils.unregister_class(SNA_OT_Update_Run_Script_Nodes_732Bd)
    bpy.types.TEXT_MT_editor_menus.remove(sna_add_to_text_mt_editor_menus_8ACED)
    bpy.utils.unregister_class(SNA_OT_Show_Run_Script_Text001_D4523)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_0D70C)
