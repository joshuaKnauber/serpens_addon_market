# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Serpens Templates",
    "author" : "skdsam", 
    "description" : "Save Serpens nodes as template to load",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Node" 
}


import bpy
import bpy.utils.previews
import json
import os
import mathutils
from bpy.app.handlers import persistent
from bpy_extras.io_utils import ImportHelper, ExportHelper
import shutil


addon_keymaps = {}
_icons = None
nodetree = {'sna_nodes': [], 'sna_nodesbpy': [], 'sna_templatenames': [], 'sna_returnednodes': [], 'sna_returnbpynodes': [], 'sna_returnloc': [], 'sna_returnwidth': [], 'sna_nodeloc': [], 'sna_nodewidth': [], }


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_405C8(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_405C8, icon, active_data, active_propname, index_405C8):
        row = layout
        layout.label(text=item_405C8.template, icon_value=752)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


class SNA_OT_Delete_E6F1A(bpy.types.Operator):
    bl_idname = "sna.delete_e6f1a"
    bl_label = "Delete"
    bl_description = "Delete the selected template"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        Removename = bpy.context.scene.sna_tempcollection[bpy.context.scene.sna_index].template
        Pathz = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')
        # Load JSON data
        with open(Pathz, "r") as f:
            data = json.load(f)
        # Remove template where name is "Group Nodes"
        data["templates"] = [t for t in data["templates"] if t["name"] != Removename]
        # Save updated JSON data
        with open(Pathz, "w") as f:
            json.dump(data, f, indent=4, sort_keys=True)
        sna_buildtemplates_5CFEE()
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def sna_buildtemplates_5CFEE():
    bpy.context.scene.sna_tempcollection.clear()
    Patherz = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')
    template_names = None
    with open(Patherz, "r") as file:
        data = json.load(file)
    template_names = [template["name"] for template in data["templates"]]
    for i_AB706 in range(len(template_names)):
        item_1956A = bpy.context.scene.sna_tempcollection.add()
        item_1956A.template = template_names[i_AB706]
    return


class SNA_OT_Name_Exists_4D643(bpy.types.Operator):
    bl_idname = "sna.name_exists_4d643"
    bl_label = "Name exists"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.template_name_ec77c', text='Try saving again with a new Name', icon_value=31, emboss=True, depress=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Template_Name_Ec77C(bpy.types.Operator):
    bl_idname = "sna.template_name_ec77c"
    bl_label = "Template Name"
    bl_description = "Save group of nodes as a template"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (len(bpy.context.selected_nodes) >= 1):
            nodetree['sna_nodes'] = []
            nodetree['sna_nodesbpy'] = []
            nodetree['sna_nodewidth'] = []
            nodetree['sna_nodeloc'] = []
            for i_D5A56 in range(len(bpy.context.selected_nodes)):
                nodetree['sna_nodewidth'].append(bpy.context.selected_nodes[i_D5A56].width)
                nodetree['sna_nodes'].append(bpy.context.selected_nodes[i_D5A56].bl_idname)
                nodetree['sna_nodeloc'].append(tuple(mathutils.Vector(bpy.context.selected_nodes[i_D5A56].location) / 1.0))
                if ('SN_BlenderPropertyNode' == bpy.context.selected_nodes[i_D5A56].bl_idname):
                    nodetree['sna_nodesbpy'].append(bpy.context.selected_nodes[i_D5A56].pasted_data_path)
                else:
                    if ('SN_SnippetNode' == bpy.context.selected_nodes[i_D5A56].bl_idname):
                        nodetree['sna_nodesbpy'].append(bpy.context.selected_nodes[i_D5A56].path)
                    else:
                        nodetree['sna_nodesbpy'].append('None')
            Patherz = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')
            Title = bpy.context.scene.sna_name
            Name_reg = None
            import numpy
            # Define the template JSON file path
            template_file = Patherz
            Name_reg = True
            # Open the template file and load the data
            with open(template_file, "r") as f:
                data = json.load(f)
            # Check if the "name" already exists in the templates list
            group_name = Title
            for template in data["templates"]:
                if template["name"] == group_name:
                    # If it exists, prompt the user to change the name
                    Name_reg = False
            # Append the new template group to the templates list
            data["templates"].append({"name": group_name, "nodes": nodetree['sna_nodes'], "zbpy": nodetree['sna_nodesbpy'], "width": nodetree['sna_nodewidth'] , "zlocation": nodetree['sna_nodeloc']  })
            # Write the updated data back to the template file
            if Name_reg:
                with open(template_file, "w") as f:
                    json.dump(data, f, indent=4, sort_keys=True)
            if (Name_reg == False):
                bpy.ops.sna.name_exists_4d643('INVOKE_DEFAULT', )
            sna_buildtemplates_5CFEE()
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        if (len(bpy.context.selected_nodes) >= 1):
            layout.prop(bpy.context.scene, 'sna_name', text='', icon_value=0, emboss=True)
        else:
            layout.label(text='Select some Nodes', icon_value=753)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Load_Template_37908(bpy.types.Operator):
    bl_idname = "sna.load_template_37908"
    bl_label = "Load template"
    bl_description = "Load the node template"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        nodetree['sna_returnednodes'] = []
        nodetree['sna_returnbpynodes'] = []
        nodetree['sna_returnloc'] = []
        nodetree['sna_returnwidth'] = []
        Pathz = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')
        NodesNames = bpy.context.scene.sna_tempcollection[bpy.context.scene.sna_index].template
        # Load JSON data
        with open(Pathz, "r") as f:
            data = json.load(f)
        # Get list of nodes where name is "Group Nodes"
        nodetree['sna_returnednodes'] = next(t["nodes"] for t in data["templates"] if t["name"] == NodesNames)
        nodetree['sna_returnbpynodes'] = next(d["zbpy"] for d in data["templates"] if d["name"] == NodesNames)
        nodetree['sna_returnwidth'] = next(s["width"] for s in data["templates"] if s["name"] == NodesNames)
        nodetree['sna_returnloc'] = next(v["zlocation"] for v in data["templates"] if v["name"] == NodesNames)
        for i_94919 in range(len(nodetree['sna_returnednodes'])):
            if ('SN_BlenderPropertyNode' == nodetree['sna_returnednodes'][i_94919]):
                node_0F232 = bpy.context.area.spaces[0].node_tree.nodes.new(type=nodetree['sna_returnednodes'][i_94919], )
                node_0F232.pasted_data_path = nodetree['sna_returnbpynodes'][i_94919]
                node_0F232.width = nodetree['sna_returnwidth'][i_94919]
                node_0F232.location = tuple(mathutils.Vector((0.0, 0.0)) + mathutils.Vector(nodetree['sna_returnloc'][i_94919]))
            else:
                if ('SN_SnippetNode' == nodetree['sna_returnednodes'][i_94919]):
                    node_F9A81 = bpy.context.area.spaces[0].node_tree.nodes.new(type=nodetree['sna_returnednodes'][i_94919], )
                    node_F9A81.width = nodetree['sna_returnwidth'][i_94919]
                    node_F9A81.location = tuple(mathutils.Vector((0.0, 0.0)) + mathutils.Vector(nodetree['sna_returnloc'][i_94919]))
                    node_F9A81.path = nodetree['sna_returnbpynodes'][i_94919]
                else:
                    node_73D53 = bpy.context.area.spaces[0].node_tree.nodes.new(type=nodetree['sna_returnednodes'][i_94919], )
                    node_73D53.width = nodetree['sna_returnwidth'][i_94919]
                    node_73D53.location = tuple(mathutils.Vector((0.0, 0.0)) + mathutils.Vector(nodetree['sna_returnloc'][i_94919]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


@persistent
def load_post_handler_057FB(dummy):
    sna_buildtemplates_5CFEE()


class SNA_OT_Refresh_Templates_3Ee47(bpy.types.Operator):
    bl_idname = "sna.refresh_templates_3ee47"
    bl_label = "Refresh Templates"
    bl_description = "Reload template document"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_buildtemplates_5CFEE()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_89050(bpy.types.Operator, ExportHelper):
    bl_idname = "sna.export_89050"
    bl_label = "Export"
    bl_description = "Export the json file"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.json', options={'HIDDEN'} )
    filename_ext = '.json'
    sna_filelocation: bpy.props.StringProperty(name='FileLocation', description='', options={'HIDDEN'}, default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        SaveLocation = self.filepath
        OldLocation = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')
        src_path = OldLocation
        dst_path = SaveLocation
        shutil.copy(src_path, dst_path)
        return {"FINISHED"}


class SNA_PT_TEMPLATES_21F51(bpy.types.Panel):
    bl_label = 'Templates'
    bl_idname = 'SNA_PT_TEMPLATES_21F51'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Serpens'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_7C6F3 = layout.row(heading='', align=False)
        row_7C6F3.alert = False
        row_7C6F3.enabled = True
        row_7C6F3.active = True
        row_7C6F3.use_property_split = False
        row_7C6F3.use_property_decorate = False
        row_7C6F3.scale_x = 1.0
        row_7C6F3.scale_y = 1.0
        row_7C6F3.alignment = 'Expand'.upper()
        row_7C6F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('405C8', locals())
        row_7C6F3.template_list('SNA_UL_display_collection_list_405C8', coll_id, bpy.context.scene, 'sna_tempcollection', bpy.context.scene, 'sna_index', rows=0)
        col_00572 = row_7C6F3.column(heading='', align=False)
        col_00572.alert = False
        col_00572.enabled = True
        col_00572.active = True
        col_00572.use_property_split = False
        col_00572.use_property_decorate = False
        col_00572.scale_x = 1.0
        col_00572.scale_y = 1.0
        col_00572.alignment = 'Expand'.upper()
        col_00572.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_00572.operator('sna.template_name_ec77c', text='', icon_value=31, emboss=True, depress=True)
        row_D343B = col_00572.row(heading='', align=False)
        row_D343B.alert = True
        row_D343B.enabled = True
        row_D343B.active = True
        row_D343B.use_property_split = False
        row_D343B.use_property_decorate = False
        row_D343B.scale_x = 1.0
        row_D343B.scale_y = 1.0
        row_D343B.alignment = 'Expand'.upper()
        row_D343B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_D343B.operator('sna.delete_e6f1a', text='', icon_value=32, emboss=True, depress=False)
        op = col_00572.operator('sna.load_template_37908', text='', icon_value=753, emboss=True, depress=True)
        col_00572.separator(factor=2.1700000762939453)
        op = col_00572.operator('sna.refresh_templates_3ee47', text='', icon_value=692, emboss=True, depress=False)
        op = col_00572.operator('sna.export_89050', text='', icon_value=69, emboss=True, depress=False)
        op.sna_filelocation = os.path.join(os.path.dirname(__file__), 'assets', 'template.json')


class SNA_GROUP_sna_temgroup(bpy.types.PropertyGroup):
    template: bpy.props.StringProperty(name='Template', description='', default='', subtype='NONE', maxlen=0)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_temgroup)
    bpy.types.Scene.sna_tempcollection = bpy.props.CollectionProperty(name='TempCollection', description='', type=SNA_GROUP_sna_temgroup)
    bpy.types.Scene.sna_index = bpy.props.IntProperty(name='Index', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_name = bpy.props.StringProperty(name='Name', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_OT_Delete_E6F1A)
    bpy.utils.register_class(SNA_OT_Name_Exists_4D643)
    bpy.utils.register_class(SNA_OT_Template_Name_Ec77C)
    bpy.utils.register_class(SNA_OT_Load_Template_37908)
    bpy.app.handlers.load_post.append(load_post_handler_057FB)
    bpy.utils.register_class(SNA_OT_Refresh_Templates_3Ee47)
    bpy.utils.register_class(SNA_OT_Export_89050)
    bpy.utils.register_class(SNA_PT_TEMPLATES_21F51)
    bpy.utils.register_class(SNA_UL_display_collection_list_405C8)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_name
    del bpy.types.Scene.sna_index
    del bpy.types.Scene.sna_tempcollection
    bpy.utils.unregister_class(SNA_GROUP_sna_temgroup)
    bpy.utils.unregister_class(SNA_OT_Delete_E6F1A)
    bpy.utils.unregister_class(SNA_OT_Name_Exists_4D643)
    bpy.utils.unregister_class(SNA_OT_Template_Name_Ec77C)
    bpy.utils.unregister_class(SNA_OT_Load_Template_37908)
    bpy.app.handlers.load_post.remove(load_post_handler_057FB)
    bpy.utils.unregister_class(SNA_OT_Refresh_Templates_3Ee47)
    bpy.utils.unregister_class(SNA_OT_Export_89050)
    bpy.utils.unregister_class(SNA_PT_TEMPLATES_21F51)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_405C8)
