# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Shitagaki",
    "author" : "Gabriel1999", 
    "description" : "Save Custom Resolutions for every frame",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "3D View > N-Panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
on_frame_change = {'sna_frame': None, }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_PT_SHITAGAKI_C8FE9(bpy.types.Panel):
    bl_label = 'Shitagaki'
    bl_idname = 'SNA_PT_SHITAGAKI_C8FE9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Shitagaki'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.data.scenes['Scene'], 'frame_end', text='Frame count', icon_value=0, emboss=True)
        row_DC5CE = layout.row(heading='', align=False)
        row_DC5CE.alert = False
        row_DC5CE.enabled = True
        row_DC5CE.active = True
        row_DC5CE.use_property_split = False
        row_DC5CE.use_property_decorate = False
        row_DC5CE.scale_x = 1.0
        row_DC5CE.scale_y = 1.0
        row_DC5CE.alignment = 'Center'.upper()
        row_DC5CE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_DC5CE.operator('sna.save_resolution_d9432', text='', icon_value=706, emboss=True, depress=False)
        col_36472 = row_DC5CE.column(heading='', align=False)
        col_36472.alert = (not property_exists("bpy.context.scene.sna_shitagaki.frame_properties[str(bpy.data.scenes['Scene'].frame_current) + '']", globals(), locals()))
        col_36472.enabled = True
        col_36472.active = True
        col_36472.use_property_split = False
        col_36472.use_property_decorate = False
        col_36472.scale_x = 1.0
        col_36472.scale_y = 1.0
        col_36472.alignment = 'Expand'.upper()
        col_36472.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_36472.prop(bpy.data.scenes['Scene'], 'frame_current', text='', icon_value=0, emboss=True)
        op = row_DC5CE.operator('sna.remove_resolution_6a233', text='', icon_value=3, emboss=True, depress=False)
        col_45912 = layout.column(heading='Resolution', align=True)
        col_45912.alert = False
        col_45912.enabled = True
        col_45912.active = True
        col_45912.use_property_split = False
        col_45912.use_property_decorate = True
        col_45912.scale_x = 1.0
        col_45912.scale_y = 1.0
        col_45912.alignment = 'Center'.upper()
        col_45912.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_45912.prop(bpy.data.scenes['Scene'].render, 'resolution_x', text='', icon_value=0, emboss=True)
        col_45912.prop(bpy.data.scenes['Scene'].render, 'resolution_y', text='', icon_value=0, emboss=True)
        layout.separator(factor=2.380000114440918)
        op = layout.operator('render.opengl', text='Viewport render', icon_value=192, emboss=True, depress=False)
        op = layout.operator('object.gpencil_add', text='Add Grease Pencil', icon_value=247, emboss=True, depress=False)
        op.type = 'LRT_OBJECT'
        op = layout.operator('object.parent_set', text='Make selected objects Parented', icon_value=175, emboss=True, depress=False)


class SNA_PT_SHITAGAKI_SETTINGS_ACF8E(bpy.types.Panel):
    bl_label = 'Shitagaki Settings'
    bl_idname = 'SNA_PT_SHITAGAKI_SETTINGS_ACF8E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Shitagaki'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Default resolution', icon_value=0)
        layout.prop(bpy.context.scene.sna_shitagaki, 'default_value', text='', icon_value=0, emboss=True)


class SNA_OT_Save_Resolution_D9432(bpy.types.Operator):
    bl_idname = "sna.save_resolution_d9432"
    bl_label = "Save Resolution"
    bl_description = "Save Resolution for current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        item_D16D7 = bpy.context.scene.sna_shitagaki.frame_properties.add()
        setattr(item_D16D7, 'name', str(bpy.context.scene.frame_current) + '')
        setattr(item_D16D7, 'size', (bpy.context.scene.render.resolution_x, bpy.context.scene.render.resolution_y))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Resolution_6A233(bpy.types.Operator):
    bl_idname = "sna.remove_resolution_6a233"
    bl_label = "Remove Resolution"
    bl_description = "Removes custom Resolution for current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        for i_800BC in range(len(bpy.context.scene.sna_shitagaki.frame_properties)):
            if bpy.context.scene.sna_shitagaki.frame_properties[i_800BC] == bpy.context.scene.sna_shitagaki.frame_properties[str(bpy.context.scene.frame_current) + '']:
                bpy.context.scene.sna_shitagaki.frame_properties.remove(i_800BC)
                break
        bpy.context.scene.render.resolution_x = bpy.context.scene.sna_shitagaki.default_value[0]
        bpy.context.scene.render.resolution_y = bpy.context.scene.sna_shitagaki.default_value[1]
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


@persistent
def frame_change_pre_handler_0DBF2(dummy):
    on_frame_change['sna_frame'] = bpy.context.scene.frame_current
    if property_exists("bpy.context.scene.sna_shitagaki.frame_properties[str(bpy.context.scene.frame_current) + '']", globals(), locals()):
        bpy.context.scene.render.resolution_x = bpy.context.scene.sna_shitagaki.frame_properties[str(bpy.context.scene.frame_current) + ''].size[0]
        bpy.context.scene.render.resolution_y = bpy.context.scene.sna_shitagaki.frame_properties[str(bpy.context.scene.frame_current) + ''].size[1]


class SNA_PT_SHITAGAKI_568CE(bpy.types.Panel):
    bl_label = 'Shitagaki'
    bl_idname = 'SNA_PT_SHITAGAKI_568CE'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_SHITAGAKI_C8FE9'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (True)

    def draw_header(self, context):
        layout = self.layout
        layout.prop(bpy.context.view_layer.objects.active, 'show_background_images', text='', icon_value=0, emboss=True)

    def draw(self, context):
        layout = self.layout
        op = layout.operator('view3d.background_image_add', text='Add Image', icon_value=0, emboss=True, depress=False)
        for i_70D9B in range(len(bpy.data.cameras['Camera'].background_images)):
            box_F7B68 = layout.box()
            box_F7B68.alert = False
            box_F7B68.enabled = True
            box_F7B68.active = True
            box_F7B68.use_property_split = False
            box_F7B68.use_property_decorate = False
            box_F7B68.alignment = 'Left'.upper()
            box_F7B68.scale_x = 1.0
            box_F7B68.scale_y = 1.0
            box_F7B68.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            box_F7B68.prop(bpy.data.cameras['Camera'].background_images[0], 'source', text='Background source', icon_value=0, emboss=True, expand=False)
            row_92FD4 = box_F7B68.row(heading='', align=False)
            row_92FD4.alert = False
            row_92FD4.enabled = True
            row_92FD4.active = True
            row_92FD4.use_property_split = False
            row_92FD4.use_property_decorate = False
            row_92FD4.scale_x = 1.0
            row_92FD4.scale_y = 1.0
            row_92FD4.alignment = 'Expand'.upper()
            row_92FD4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_92FD4.prop(bpy.data.cameras['Camera'].background_images[0], 'image', text='Background source', icon_value=0, emboss=True, expand=False)
            op = row_92FD4.operator('image.open', text='', icon_value=693, emboss=True, depress=False)
            for i_C548E in range(len([])):
                box_F7B68.label(text='No Property connected!', icon='ERROR')


class SNA_GROUP_sna_shitagaki_frames_properties(bpy.types.PropertyGroup):
    size: bpy.props.IntVectorProperty(name='size', description='', size=2, default=(1920, 1080), subtype='NONE', min=1)


class SNA_GROUP_sna_shitagaki_pointer_group(bpy.types.PropertyGroup):
    frame_properties: bpy.props.CollectionProperty(name='Frame properties', description='', type=SNA_GROUP_sna_shitagaki_frames_properties)

    default_value: bpy.props.IntVectorProperty(name='Default Value', description='Define default x, y values', size=2, default=(1920, 1080), subtype='NONE', min=4)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_shitagaki_frames_properties)
    bpy.utils.register_class(SNA_GROUP_sna_shitagaki_pointer_group)
    bpy.types.Scene.sna_shitagaki = bpy.props.PointerProperty(name='Shitagaki', description='', type=SNA_GROUP_sna_shitagaki_pointer_group)
    bpy.utils.register_class(SNA_PT_SHITAGAKI_C8FE9)
    bpy.utils.register_class(SNA_PT_SHITAGAKI_SETTINGS_ACF8E)
    bpy.utils.register_class(SNA_OT_Save_Resolution_D9432)
    bpy.utils.register_class(SNA_OT_Remove_Resolution_6A233)
    bpy.app.handlers.frame_change_pre.append(frame_change_pre_handler_0DBF2)
    bpy.utils.register_class(SNA_PT_SHITAGAKI_568CE)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_shitagaki
    bpy.utils.unregister_class(SNA_GROUP_sna_shitagaki_pointer_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_shitagaki_frames_properties)
    bpy.utils.unregister_class(SNA_PT_SHITAGAKI_C8FE9)
    bpy.utils.unregister_class(SNA_PT_SHITAGAKI_SETTINGS_ACF8E)
    bpy.utils.unregister_class(SNA_OT_Save_Resolution_D9432)
    bpy.utils.unregister_class(SNA_OT_Remove_Resolution_6A233)
    bpy.app.handlers.frame_change_pre.remove(frame_change_pre_handler_0DBF2)
    bpy.utils.unregister_class(SNA_PT_SHITAGAKI_568CE)
